function bw = GaussianFitBW(img,bw_where,tol)
% In every nuclei, find foci by 2D gaussian fit

img = double(img);
lab = bwlabel(bw_where);
d = regionprops(lab,'BoundingBox');
for i = 1:length(d)
    rect = d(i,1).BoundingBox;
    rect = ceil(rect);
    if rect(2)+rect(4)>size(img,1)
        row = size(img,1);
    else
        row = rect(2)+rect(4);
    end
    if rect(1)+rect(3)>size(img,2);
        column = size(img,2);
    else
        column = rect(1)+rect(3);
    end
    sub = img(rect(2):row, rect(1):column);
    [fit,cx,cy,sx,sy,PeakOD] = Fit2DMesh(sub,tol);
    cutoff = Cutoff2DGaussian(sub,cx,cy,sx,sy);
    img = removeedge(img,rect,cutoff);
    disp(i);
end
bw = img & bw_where;


function img = removeedge(img,rect,cutoff)

if rect(2)+rect(4)>size(img,1)
    row=size(img,1);
else
    row = rect(2)+rect(4);
end
if rect(1)+rect(3)>size(img,2)
    column = size(img,2);
else
    column = rect(1)+rect(3);
end
for i = rect(2):row
    for j = rect(1):column
        if img(i,j)<cutoff
            img(i,j) = 0;
        end
    end
end