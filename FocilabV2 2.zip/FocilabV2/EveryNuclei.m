function singlefoci = EveryNuclei(bw,cen)
% compute the number of foci and overlap foci in every nucleus

if strcmp(bw,'no_mask')
    singlefoci = [];
    return;
end
bound = bwboundaries(bw);
singlefoci = zeros(length(bound),2);
for i = 1:length(bound)
    singlefoci(i,1) = i;
    singlefoci(i,2) = NumOfFoci(bound{i,1},cen);
end

function id = NumOfFoci(bound,cen)
% return the the number of foci in a single nucleus

id = 0;
for i = 1:size(cen,1)
    if inpolygon(cen(i,3),cen(i,2),bound(:,1),bound(:,2))
        id = id +1;
    end
end
