function v = vspixel(pixel, num)
% vs is short for vector same
% construct a vector in which there are  same pixel,accoring to num.
% e.g. vspixel(3,5)       v = [3 3 3 3 3];
% e.g. vspixel(4,6)       v = [4 4 4 4 4 4];

v = [];
n = 1;
for i =1: num
    if num == 0 
        v(i) = [];
    else
        v(n) = pixel;
        n = n+1; 
    end
end