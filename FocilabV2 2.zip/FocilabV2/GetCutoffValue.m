function cutoff = GetCutoffValue(x,y,times)
% this function transform the time * deviation + mean to cutoff value.
% the gradx is the all the grads.
% the grady is the number of specified grad.


v = [];
sparray = [];

for i = 1:length(x)
    v = vspixel(x(i),y(i));
    sparray = [sparray,v];
end

cutMean = mean(sparray);
cutStd = std(sparray);

cutoff = times * cutStd + cutMean;