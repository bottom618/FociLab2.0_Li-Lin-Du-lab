function gmatrix=GradImgMesh(imori,cellarray,nobj,neobj)
% return a grad matrix based on the mask-foci image and the  original image.
% imori is the original foci image.
% cellarray that is cell array, stores the coordinate of every object.
% nobj is the number of all object.
% neobj is the number of every object.

imori = double(imori);
[M,N] = size(imori);
gmatrix = zeros(M,N);
GL = 2;    % the grad length
for i = 1:nobj
    gvector = [];
    if neobj(i)~=1
        for j = 1: neobj(i)
            r = cellarray{i,1}(j);
            c = cellarray{i,2}(j);
            if r - GL>=1 && r + GL <= M && c - GL >=1 && c +GL <=N
                gvector(i) = imori(r,c).*8 - imori(r-2,c-2) - imori(r-2,c) - imori(r-2,c+2)...
                    -imori(r,c-2) - imori(r,c+2) - imori(r+2,c-2) - imori(r+2,c) - imori(r+2,c+2);
                gmatrix(r,c) = gvector(i);
            end
        end
    end
end
