function [linx,liny,cor] = GetSlideD(sptx,spty,satmark,satval)
% According to the coordinates of the scatter spots, we can compute the
% polyfit line. linx is the x- axis coordinates of the line. liny is the y-
% axis coordintes of the line.
% satmark will tell us whether some saturated spots are deleted. If
% satmark=1, they will be deleted; mark = 0, can not .
% satval is the saturated value.

% first judge whether exist the saturated spots
if satmark == 1
    posx = find(sptx == satval); % find the saturated spots
    posy = find(spty == satval);  % find the saturated spots
    if ~(isempty(posx) || isempty(posy))
    sptx(posx) = 0;
    spty(posy) = 0;
    pos = sptx & spty;   % select the non-saturated spots
    sptx = sptx(pos);
    spty = spty(pos);
    end % if
end
cor = corr2(sptx,spty);
p = polyfit(sptx,spty,1);
slide = p(1);
d = p(2);
linx = 1:1:max(sptx);
liny = slide.* linx + d;

