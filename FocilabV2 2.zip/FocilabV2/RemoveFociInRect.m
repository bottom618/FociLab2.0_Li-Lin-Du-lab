function bwout = RemoveFociInRect(bw,rect)
% we will remove the foci in the rect.

lab = bwlabel(bw);
d = regionprops(lab,'Centroid');
% get the edge of rect

% initialzie a temp bw
tmpbw = false(size(bw));
rect = round(rect);
tmpbw(rect(2):rect(2)+rect(4),rect(1):rect(1)+rect(3))=1;
bound = bwboundaries(tmpbw);
for i = 1:length(d)
    cen1 = round(d(i,1).Centroid(1));
    cen2 = round(d(i,1).Centroid(2));
    in = inpolygon(cen1,cen2,bound{1,1}(:,2),bound{1,1}(:,1));
    if in % remove this foci
        [r,c] = find(lab == i);
        for i = 1:length(r)
            bw(r(i),c(i)) = 0;
        end
    end
end
bwout = bw;

