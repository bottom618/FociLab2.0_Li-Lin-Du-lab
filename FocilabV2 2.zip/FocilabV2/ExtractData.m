rootfolder = '';
program = '';
fmask = 'where_to_find_foci';
f632 = '632info';
f535 = '535info';
f470 = '470info';
subfolder = dir(rootfolder);

for i = 3:length(subfoler) -2
    subfile = dir(strcat(rootfolder,subfolder(i,1).name,'\'));
    file = dir(subfile);
    for j = 3:length(file)-2
        filename = file(j,1).name;
        switch filename(end-2,end)
            case 'xls'
                if ~isempty(fmask) && ~isempty(regexp(filename,fmask,'once'))
                    mymask = strcat(subfile,filename);
                end
                if ~isempty(foci632) && ~isempty(regexp(filename,f632(1:3),'once')) && ~isempty(regexp(filename,f632(4:end),'once'))
                    my632 = strcat(subfile,filename);
                end
                if ~isempty(foci535) && ~isempty(regexp(filename,f535(1:3),'once')) && ~isempty(regexp(filename,f535(4:end),'once'))
                    my535 = strcat(subfile,filename);
                end
                if ~isempty(foci470) && ~isempty(regexp(filename,f470(1:3),'once')) && ~isempty(regexp(filename,f470(4:end),'once'))
                    my470 = strcat(subfile,filename);
                end                
            otherwise
                continue
        end     
    end
    %perl 
end
