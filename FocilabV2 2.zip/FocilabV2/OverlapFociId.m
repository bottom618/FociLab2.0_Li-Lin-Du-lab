function overlapinfo = OverlapFociId(basecen,refcen,dis)
% we will find which foci overlap with 'basecen' foci;
% output format
% baseid refid
% 1  3
% 2  5
% 3  0 (0 stand for none of foci in ref overlap with base foci);
% ..  ..
% dis indicate how much close to base foci is referred to as overlap foci
% overlapinfo is cell type

overlapinfo = zeros(size(basecen,1),2);
for i = 1:size(basecen,1)
    id = FindOverlapId(basecen(i,2:3),refcen,dis);
    overlapinfo(i,1) = i;
    overlapinfo(i,2) = id(1);
end

function fociid = FindOverlapId(cen,refcen,dis)

id =[];
tmepdis=[];
for i = 1:size(refcen,1)
    distance = GetDist(cen,refcen(i,2:3));
    if distance <= dis
        tmepdis = [tmepdis distance];
        id = [id i];
    end
end
if isempty(id)
    fociid = 0;
else 
    pos = find(tmepdis == min(tmepdis));
    fociid = id(pos);
end


function distance = GetDist(cen1,cen2)
distance = sqrt((cen1(1)-cen2(1)).^2+(cen1(2)-cen2(2)).^2);

