function mark = OutputFociInfo(foci)
% output the foci information

if foci.WhetherExist == 0
    disp('This channel does not exist!');
    mark = 1;
    return;
end

filename = foci.FileName;
filename = strcat(filename(1:end-4),'_foci_info.xls');
dependentintensity = foci.DependentIntensity;
centroid = foci.Centroid;
area = foci.Area;
perimeter = foci.Perimeter;
intensity = foci.Intensity;
nucleiid = foci.NucleiId;
overlapwithfoci1 = foci.OverlapWithFoci1;
overlapwithfoci2 = foci.OverlapWithFoci2;


fid = fopen(filename,'w');

fprintf(fid,'file name: \t\t%s\n\n',filename);
fprintf(fid,'%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n','fociid','centroidx','centroidy','area','perimeter','maxintensity','meanintensity','minintensity','nucleusid','overlapwithfoci1','overlapwithfoci2','dependent_intensity');
for i = 1:size(centroid,1);
    fprintf(fid,'%d\t',i);
    fprintf(fid,'%.2f\t%.2f\t',centroid(i,3),centroid(i,2));
    fprintf(fid,'%d\t',area(i,2));
    fprintf(fid,'%.2f\t',perimeter(i,2));
    fprintf(fid,'%d\t%.2f\t%d\t',intensity(i,2),intensity(i,3),intensity(i,4));
    fprintf(fid,'%d\t',nucleiid(i,2));
    if ~isempty(overlapwithfoci1)
        fprintf(fid,'%d\t',overlapwithfoci1(i,2));
    else
        fprintf(fid,'%d\t',-1);
    end
    if ~isempty(overlapwithfoci2)
        fprintf(fid,'%d\t',overlapwithfoci2(i,2));
    else
        fprintf(fid,'%d\t',-1);
    end
    if strcmp(foci.DependentOn,'self')
        fprintf(fid,'\n');
    else
        fprintf(fid,'%d\n',dependentintensity(i,5));
    end
end

fclose(fid);

mark = 1;