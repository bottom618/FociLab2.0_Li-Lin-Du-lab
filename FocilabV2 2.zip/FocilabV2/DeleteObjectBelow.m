function bwout = DeleteObjectBelow(bw,value1,value2)
% This function is used to delete samller object or bigger object.
% that is, we will remain the object value1<object area <value2

[lab,n] = bwlabel(bw);
D = regionprops(lab,'Area');
area = zeros(1,n);
for i = 1: n
    area(i) = D(i,1).Area;
end
if  value1<0 || value2<0
    error('Parameters can not be negative.');
end
if value1 == 0 && value2>0 % only delete the bigger object
    id = find(area>value2);
elseif value1>0 && value2==0 %only delete the smaller object
    id = find(area<value1);
elseif value1 >0 && value2>0 && value2>value1% only delete the suitable object
    id = find(area<value1 | area>value2);
elseif value1 == 0 && value2==0 
    bwout = bw;
    return;
else 
    error('there is not this case in parameters setting.');
end

for i = 1:length(id)
    [r,c] = find(lab == id(i));
    for j =1:length(r)
        bw(r(j),c(j)) = 0;
    end
end
bwout = bw;