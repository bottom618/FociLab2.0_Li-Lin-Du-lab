function mask = ConstructMask(mask)
% this function is used to construct mask information

%% ----------------------mask file---------------------
% dealing with the mask file
% mask_file = mask.FileName;
% if isempty(mask_file)
%     disp('mask file is null.');
%     mask.BW=[];
%     mask.WhetherExists = 0;
%     return;
% else 
%     mask.WhetherExists = 1;
%     img_mask = imread(mask_file);
% end
% %get the bw image
% switch mask.ObjectFindingMethod
%     case 'Otsu'
%         bw = MaskfileToBW(img_mask,0);
%     case 'None'
%         bw_gray = img_mask;
%     otherwise
%         error('I cann''t find the object finding method.');
% end
if mask.WhetherExist == 0
    disp('Find foci through the total image!');
    return;
end

img_mask = imread(mask.FileName);
% whether keep the reasonable object
area_below = mask.DeleteObjectBelow;
%if ~isempty(area_below)
    bw = DeleteObjectBelow(mask.BW,area_below(1),area_below(2));
%end
% whether remove the marginal object
if mask.DeleteMarginalObject == 1
    bw = DeleteMarginalObject(bw);
end
% give the mask object properties
mask.Centroid = GetBWRegionProp(img_mask,bw,'object centroid');
mask.Area = GetBWRegionProp(img_mask,bw,'area');
mask.Perimeter = GetBWRegionProp(img_mask,bw,'perimeter');
mask.MajorAxisLength = GetBWRegionProp(img_mask,bw,'major axis length');
mask.MinorAxisLength = GetBWRegionProp(img_mask,bw,'minor axis length');
mask.Intensity = GetBWRegionProp(img_mask,bw,'intensity');
mask.BoundingBox = GetBWRegionProp(img_mask,bw,'boundingbox');
%if isempty(bw)
   %mask.BW = 'no_mask';
%else 
   mask.BW = bw;
%end
% get object number
mask.ObjectNum = size(mask.Centroid,1);
