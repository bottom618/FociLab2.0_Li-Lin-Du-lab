function mark = OutputMaskInfo(mask)
% output the information

mark =0; % mark for successful operation
if mask.WhetherExist == 0
    disp('This channel does not exist!');
    mark = 1;
    return;
end

filename = mask.FileName;
filename = strcat(filename(1:end-4),'_where_to_find_foci.xls');

centroid = mask.Centroid;
area = mask.Area;
perimeter = mask.Perimeter;
majoraxislength = mask.MajorAxisLength;
minoraxislength = mask.MinorAxisLength;
intensity = mask.Intensity;
single632foci = mask.Single632FociNum;
single535foci = mask.Single535FociNum;
single470foci = mask.Single470FociNum;
single632535num = mask.Single632535Num;
single632470num = mask.Single632470Num;
single535470num = mask.Single535470Num;
foci632num = mask.Foci632Num;
foci535num = mask.Foci535Num;
foci470num = mask.Foci470Num;
overlaprg = mask.OverlapRG;
overlaprb = mask.OverlapRB;
overlapgb = mask.OverlapGB;
objectnum = mask.ObjectNum;

fid = fopen(filename,'w');
fprintf(fid,'file name: \t\t%s\n',filename);
fprintf(fid,'object number: \t\t%d\n',objectnum);
fprintf(fid,'foci number in wave 632: \t\t%d\n',foci632num);
fprintf(fid,'foci number in wave 535: \t\t%d\n',foci535num);
fprintf(fid,'foci number in wave 470: \t\t%d\n',foci470num);
fprintf(fid,'632 and 535 overlap foci number:\t %d\tcorrelation:\t%.3f\n',overlaprg(1),overlaprg(2));
fprintf(fid,'632 and 470 overlap foci number:\t %d\tcorrelation:\t%.3f\n',overlaprb(1),overlaprb(2));
fprintf(fid,'535 and 470 overlap foci number:\t %d\tcorrelation:\t%.3f\n\n',overlapgb(1),overlapgb(2));

fprintf(fid,'%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n','objectid','centroidx','centroidy','area','perimeter','major_axis_length','minor_axis_length','maxintensity','meanintensity','minintensity','632foci','535foci','470foci','632535foci','632470foci','535470foci');
%printf(fid,'%s',dat);

    for i = 1:mask.ObjectNum
       fprintf(fid,'%d\t',i);
       fprintf(fid,'%.2f\t%.2f\t',centroid(i,3),centroid(i,2));
       fprintf(fid,'%d\t',area(i,2));
       fprintf(fid,'%.2f\t',perimeter(i,2));
       fprintf(fid,'%.2f\t',majoraxislength(i,2));
       fprintf(fid,'%.2f\t',minoraxislength(i,2));
       fprintf(fid,'%d\t%.2f\t%d\t',intensity(i,2),intensity(i,3),intensity(i,4));
       fprintf(fid,'%d\t%d\t%d\t',single632foci(i,2),single535foci(i,2),single470foci(i,2));
       if ~isempty(single632535num)
           fprintf(fid,'%d\t',single632535num(i,2));
       else 
           fprintf(fid,'%d\t',-1);
       end
       if ~isempty(single632470num)
           fprintf(fid,'%d\t',single632470num(i,2));
       else
           fprintf(fid,'%d\t',-1);
       end
       if ~isempty(single535470num);
           fprintf(fid,'%d\n',single535470num(i,2));
       else
           fprintf(fid,'%d\n',-1);
       end
    end
    
fclose(fid);
mark =1;



