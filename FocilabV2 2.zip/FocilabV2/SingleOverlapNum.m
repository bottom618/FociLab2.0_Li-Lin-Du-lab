function overlapfocinum = SingleOverlapNum(bw,cen,overlapcen)
% return the number of overlap foci num

if isempty(overlapcen) || strcmp(bw,'no_mask')
    overlapfocinum = [];
    return
end 
bound = bwboundaries(bw);
overlapfocinum = zeros(size(cen,1),2);
for i = 1:length(bound)
    overlapfocinum(i,1) = i;
    overlapfocinum(i,2) = NumOfFoci(bound{i,1},cen,overlapcen);
end

function id = NumOfFoci(bound,cen,overlapcen)
% return the the number of foci in a single nucleus

id = 0;
for i = 1:size(cen,1)
    if overlapcen(i,2) ~=0 % verify it is overlap foci
        if inpolygon(cen(i,3),cen(i,2),bound(:,1),bound(:,2))
            id = id +1;
        end
    end
end
