function [gmatrixarray, bwgmatrix] = GetBWGmatrix(numset,cutoff,minimumcutoff)
%According to cut-off  value, get bw grads matrix.

numset = double(numset);
[M,N] = size(numset);
bwgmatrix = zeros(M,N);
gmatrixarray = [];
k=1;
for i = 1:M
    for j = 1:N
        if numset(i,j)>cutoff && numset(i,j)>minimumcutoff
            bwgmatrix(i,j) = 1;
            gmatrixarray(k) = numset(i,j);
            k = k+1;

        end
    end
end