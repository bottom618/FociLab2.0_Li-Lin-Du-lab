function bw= OnlyOneFocus(bwmask,bwfoci,fociimg)
% In every object, there is only one focus. We will remove the the samller
% and dimmer redudant focus in the object.

bound = bwboundaries(bwmask);
bwtemp = bwfoci;
lab = bwlabel(bwfoci);
d = regionprops(lab,fociimg,'Centroid','MaxIntensity');
cen = zeros(length(d),3);
for i = 1:length(d)
    cen(i,1) = i;
    cen(i,2) = d(i,1).Centroid(1);
    cen(i,3) = d(i,1).Centroid(2);
end
for i = 1:length(bound)
    b = bound{i,1};
    id = TestFociInMask(b,cen);
    if ~isempty(id) && length(id)>1
        bwtemp=RemainBrighterSpot(d,id,bwfoci,bwtemp);
    end
end
bw = bwtemp;

function id = TestFociInMask(bound,cen)
% bound is the boundaries of a nucleus
% cen is all foci centroid,whose format is fociid cenx ceny

id = [];
for i = 1:size(cen,1)
    if inpolygon(cen(i,3),cen(i,2),bound(:,1),bound(:,2));
        id = [id i];
    end
end

function bwtemp = RemainBrighterSpot(d,id,bw,bwtemp)
% id stored the foci number in the same nuclei
% d is the struct of all foci

lab = bwlabel(bw);
intid = zeros(1,length(id));
for i = 1:length(id)
    intid(i)  = d(id(i),1).MaxIntensity;
end
num = find(intid < max(intid));
for i = 1:length(num)
    [r,c] = find(lab == id(num(i)));
    for j = 1:length(r)
        bwtemp(r(j),c(j)) = 0;
    end
end
