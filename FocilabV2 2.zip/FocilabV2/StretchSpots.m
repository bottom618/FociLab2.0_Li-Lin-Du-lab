function [bw,modified] = StretchSpots(orimg,bw)
% Stretch the spots according to the average intensity of every spot.
% orimg is the original image.
% bw is a binary image of spots.
% The average intensity is used to be the norm of stretching.

modified = 0;
[g,nr] = bwlabel(bw);

orimg = double(orimg);
% get average gray in every object as a standard to decide whether to set
% a pixel around the white spot into the whole part.
avergray = zeros(1,nr);
for i = 1: nr
    [r,c] = find(g == i);   %The coordinate of every pixel in every object
    isum = 0;
    for j = 1:length(r)
        isum = orimg(r(j),c(j)) + isum;
    end
    avergray(i) = isum./length(r);
end

for i = 1: nr
    [r,c] = find(g == i);
    for j = 1: length(r)
        mark = JudgeEdgeSpot(bw,r(j),c(j));
        if mark
            if r(j)-1>=1 && r(j)-1<=size(orimg,1) && c(j)-1>=1 && c(j)-1<=size(orimg,2)
            if bw(r(j)-1,c(j)-1) == 0
                if orimg(r(j)-1,c(j)-1)>avergray(i)
                    bw(r(j)-1,c(j)-1) = 1;
                    modified = 1;
                end
            end
            end
            if r(j)-1>=1 && r(j)-1<=size(orimg,1)
            if bw(r(j)-1,c(j)) == 0
                if orimg(r(j)-1,c(j))>avergray(i)
                    bw(r(j)-1,c(j)) = 1;
                    modified = 1;
                end
            end
            end
            if r(j)-1>=1 && r(j)-1<=size(orimg,1) && c(j)+1>=1 && c(j)+1<=size(orimg,2)
            if bw(r(j)-1,c(j)+1) == 0
                if orimg(r(j)-1,c(j)+1)>avergray(i)
                    bw(r(j)-1,c(j)+1) = 1; 
                    modified = 1;
                end
            end
            end
            if  c(j)-1>=1 && c(j)-1<=size(orimg,2)
            if bw(r(j),c(j)-1) ==0
                if orimg(r(j),c(j)-1)>avergray(i)
                    bw(r(j),c(j)-1) =1;
                    modified = 1;
                end
            end
            end
            if c(j)+1>=1 && c(j)+1<=size(orimg,2)
            if bw(r(j),c(j)+1) == 0
                if orimg(r(j),c(j)+1) > avergray(i)
                    bw(r(j),c(j)+1) = 1;
                    modified = 1;
                end
            end
            end
            if r(j)+1>=1 && r(j)+1<=size(orimg,1) && c(j)-1>=1 && c(j)-1<=size(orimg,2)
            if bw(r(j)+1,c(j)-1) == 0
                if orimg(r(j)+1,c(j)-1) > avergray(i)
                    bw(r(j)+1,c(j)-1) = 1;
                    modified = 1;
                end
            end
            end
            if r(j)+1>=1 && r(j)+1<=size(orimg,1)
            if bw(r(j)+1,c(j)) == 0
                if orimg(r(j)+1,c(j))> avergray(i)
                    bw(r(j)+1,c(j)) = 1;
                    modified = 1;
                end
            end
            end
            if r(j)+1>=1 && r(j)+1<=size(orimg,1) && c(j)+1>=1 && c(j)+1<=size(orimg,2)
            if bw(r(j)+1,c(j)+1) == 0
                if orimg(r(j)+1,c(j)+1)>avergray(i)
                    bw(r(j)+1,c(j)+1) =1;
                    modified = 1;
                end
            end
            end
        end
    end
end



function mark = JudgeEdgeSpot(bw,x,y)
% estimate whether the spot is a edge spot.
% (x,y) is the coordinate of edge pixel.
%  img is spot image.

if x-1>=1 && x+1<=size(bw,1) && y-1>=1 && y+1<=size(bw,2)
    if (bw(x-1,y-1) & bw(x-1,y-1) & bw(x-1,y-1) & ...
             bw(x,y-1)  & bw(x,y+1) & ...
             bw(x+1,y+1) & bw(x+1,y+1) & bw(x+1,y+1)) == 0
         mark = 1;
    else
        mark = 0;
    end
else
 mark = 0;
end

