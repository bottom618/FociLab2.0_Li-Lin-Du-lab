function [gmatrix,gradx,grady] = GetGradInfo(img,bw)
% This function is used to get info about grads and distribution of grads.
% Img is the source image. bw is the mask img.

[nobj, cellarray, neobj] = GetIndexMask(bw);
gmatrix = GradImgMesh(img,cellarray,nobj,neobj);
[gradx,grady] = GetDist(gmatrix);