function varargout = gui_formal(varargin)
% GUI_FORMAL M-file for gui_formal.fig
%      GUI_FORMAL, by itself, creates a new GUI_FORMAL or raises the existing
%      singleton*.
%
%      H = GUI_FORMAL returns the handle to a new GUI_FORMAL or the handle to
%      the existing singleton*.
%
%      GUI_FORMAL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI_FORMAL.M with the given input arguments.
%
%      GUI_FORMAL('Property','Value',...) creates a new GUI_FORMAL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui_formal_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui_formal_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui_formal

% Last Modified by GUIDE v2.5 19-May-2010 15:24:08

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gui_formal_OpeningFcn, ...
                   'gui_OutputFcn',  @gui_formal_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gui_formal is made visible.
function gui_formal_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui_formal (see VARARGIN)

% read eye icon
eye = imread('eye.bmp');
%eye = uint8(double(eye).*175);
 img_eye(:,:,1) = double(eye);
 img_eye(:,:,2) = double(eye);
 img_eye(:,:,3) = double(zeros(size(eye)));

grad = imread('grad.bmp');

set(handles.btn_maskfileshow,'CData',img_eye);
set(handles.btn_waveshow,'CData',img_eye);
set(handles.btn_wavecropshow,'CData',img_eye);
set(handles.btn_waveshowgrad,'CData',grad);
bw_eye(:,:,1) = double(eye);
bw_eye(:,:,2) = double(eye);
bw_eye(:,:,3) = double(eye);
set(handles.btn_maskfilebwshow,'CData',bw_eye);

%set the radio button for choosing the centroid option
set(handles.rad_waveobjectcentroid,'Value',1);
set(handles.rad_waveweightedcentroid,'Value',0);
% set mask option button
set(handles.chk_maskfileremovearea,'Value',0);
set(handles.edt_maskfileareabelow,'Enable','off');
set(handles.edt_maskfileareagreat,'Enable','off');
set(handles.chk_maskfilemarginal,'Value',0)

% set the wave additional option
set(handles.chk_waveremovefoci,'Value',0);
set(handles.edt_waveareabelow,'Enable','off');
set(handles.chk_waveonlyonefocus,'Value',0);
set(handles.chk_waveintensitycomparison,'Value',0);
set(handles.pop_waveintensitycomparison,'Enable','off');
set(handles.edt_wavetimes,'String',3);
set(handles.chk_waveminimumcutoff,'Value',1);
set(handles.edt_waveminimumcutoff,'String',200);
% set overlap distance setting
set(handles.edt_overlap632535,'String',1);
set(handles.edt_overlap632470,'String',1);
set(handles.edt_overlap535470,'String',1);
handles.filepath = '';

%% initialize mask and foci structure
mask = struct('FileName','',...
              'WhetherExist',0,...
              'ObjectFindingMethod','Otsu',...% include two choice: Otsu and None,if is none,get grads from the whole image
              'DeleteObjectBelow',[0 0],...
              'DeleteMarginalObject',0,...
              'Centroid',[],...
              'Area',[],...
              'Perimeter',[],...
              'MajorAxisLength',[],...
              'MinorAxisLength',[],...
              'Intensity',[],...
              'BoundingBox',[],...
              'Single632FociNum',[],...
              'Single535FociNum',[],...
              'Single470FociNum',[],...
              'Single632535Num',[],...
              'Single632470Num',[],...
              'Single535470Num',[],...
              'Foci632Num',0,...
              'Foci535Num',0,...
              'Foci470Num',0,...
              'OverlapRG',[0 0],...%have two data,the first is overlap num;the second is correlation
              'OverlapRB',[0 0],...%the same to above
              'OverlapGB',[0 0],...%the same to above
              'OverlapDistanceRG',1,...
              'OverlapDistanceRB',1,...
              'OverlapDistanceGB',1,...
              'ObjectNum',0,...
              'CorrIntensity','MaxIntensity',...
              'SaturatedIntensity',4095,...
              'BW','no_mask');%
%% initialize foci application data
foci632 = struct('FileName','',...
                 'WhetherExist',0,...
                 'ParticleFindingMethod','grad info',...
                 'TimesStd',3,...
                 'FitLine',[],...
                 'ContourLevel',2,...
                 'MinimumCut',200,...
                 'WhetherRemoveRect',0,...
                 'RemoveRect',[0 0 0 0],...
                 'DefineCenter','object centroid',...
                 'DeleteFociBelow',0,...
                 'OnlyOneFocus',0,...
                 'DependentOn','self',...
                 'DependentIntensity',[],...
                 'Centroid',[],...
                 'Area',[],...
                 'Perimeter',[],...
                 'Intensity',[],...
                 'NucleiId',[],...
                 'OverlapWithFoci1',[],...
                 'OverlapWithFoci2',[],...
                 'BW',[]);%the first column is overlp with 535; the second is 470;
foci535 = struct('FileName','',...
                 'WhetherExist',0,...
                 'ParticleFindingMethod','grad info',...
                 'TimesStd',3,...
                 'FitLine',[],...
                 'ContourLevel',2,...
                 'MinimumCut',200,...
                 'WhetherRemoveRect',0,...
                 'RemoveRect',[0 0 0 0],...
                 'DefineCenter','object centroid',...
                 'DeleteFociBelow',0,...
                 'OnlyOneFocus',0,...
                 'DependentOn','self',...
                 'DependentIntensity',[],...
                 'Centroid',[],...
                 'Area',[],...
                 'Perimeter',[],...
                 'Intensity',[],...
                 'NucleiId',[],...
                 'OverlapWithFoci1',[],...
                 'OverlapWithFoci2',[],...
                 'BW',[]);%the first column is overlp with 535; the second is 470;
foci470 = struct('FileName','',...
                 'WhetherExist',0,...
                 'ParticleFindingMethod','grad info',...
                 'TimesStd',3,...
                 'FitLine',[],...
                 'ContourLevel',2,...
                 'MinimumCut',200,...
                 'WhetherRemoveRect',0,...
                 'RemoveRect',[0 0 0 0],...
                 'DefineCenter','object centroid',...
                 'DeleteFociBelow',0,...
                 'OnlyOneFocus',0,...
                 'DependentOn','self',...
                 'DependentIntensity',[],...
                 'Centroid',[],...
                 'Area',[],...
                 'Perimeter',[],...
                 'Intensity',[],...
                 'NucleiId',[],...
                 'OverlapWithFoci1',[],...
                 'OverlapWithFoci2',[],...
                 'BW',[]);%the first column is overlp with 535; the second is 470;
%%
handles.mask = mask;
handles.foci632 = foci632;
handles.foci535 = foci535;
handles.foci470 = foci470;
% Choose default command line output for gui_formal
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes gui_formal wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = gui_formal_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in pop_wave.
function pop_wave_Callback(hObject, eventdata, handles)
% hObject    handle to pop_wave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns pop_wave contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pop_wave
val = get(hObject,'Value');
wave = get(hObject,'String');
switch wave{val}
    case 'wave632'
        set(handles.pal_wave,'Title','Wave632');
        foci = handles.foci632;
        if foci.DeleteFociBelow ~= 0
            set(handles.edt_waveareabelow,'enable','on');
        else
            set(handles.edt_waveareabelow,'Enable','off');
        end
        if foci.MinimumCut > 0
            set(handles.edt_waveminimumcutoff,'Enable','on');
        else
            set(handles.edt_waveminimumcutoff,'Enable','off');
        end
        if strcmp(foci.DependentOn,'self')
            set(handles.pop_waveintensitycomparison,'Enable','off');
        else
            set(handles.pop_waveintensitycomparison,'Enable','on');
        end
        ShowWaveData(foci,handles);
    case 'wave535'
        set(handles.pal_wave,'Title','Wave535');
        foci = handles.foci535;
        %disp(class(foci))
        if foci.DeleteFociBelow ~= 0
            set(handles.edt_waveareabelow,'Enable','on');
        else
            set(handles.edt_waveareabelow,'Enable','off');
        end
        if foci.MinimumCut > 0
            set(handles.edt_waveminimumcutoff,'Enable','on');
        else
            set(handles.edt_waveminimumcutoff,'Enable','off');
        end
        if strcmp(foci.DependentOn,'self')
            set(handles.pop_waveintensitycomparison,'Enable','off');
        else
            set(handles.pop_waveintensitycomparison,'Enable','on');
        end
        ShowWaveData(foci,handles);
    case 'wave470'
        set(handles.pal_wave,'Title','Wave470');
        foci = handles.foci470;
        if foci.DeleteFociBelow ~= 0
            set(handles.edt_waveareabelow,'Enable','on');
        else
            set(handles.edt_waveareabelow,'Enable','off');
        end
        if foci.MinimumCut > 0
            set(handles.edt_waveminimumcutoff,'Enable','on');
        else
            set(handles.edt_waveminimumcutoff,'Enable','off');
        end
        if strcmp(foci.DependentOn,'self')
            set(handles.pop_waveintensitycomparison,'Enable','off');
        else
            set(handles.pop_waveintensitycomparison,'Enable','on');
        end
        ShowWaveData(foci,handles);
end

% --- Executes during object creation, after setting all properties.
function pop_wave_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pop_wave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btn_batchwork.
function btn_batchwork_Callback(hObject, eventdata, handles)
% hObject    handle to btn_batchwork (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

mask = handles.mask;
maskmark = mask.FileName;
foci632 = handles.foci632;
foci535 = handles.foci535;
foci470 = handles.foci470;


if isdir(foci632.FileName)
    batchfolder = foci632.FileName;
elseif isdir(foci535.FileName)
    batchfolder = foci535.FileName;
elseif isdir(foci470.FileName)
    batchfolder = foci470.FileName;
else
    msgbox('No directory!','WARN','warn');
    return;
end
if ~strcmp(batchfolder(end),'\')
    batchfolder = strcat(batchfolder,'\');
end

subfolder = dir(batchfolder);

h = waitbar(0,'File is ruuning...');
sublength = length(subfolder) -2;
for i = 3:length(subfolder)
    myfilename = strcat(batchfolder,subfolder(i,1).name,'\');
    waitbar((i-2)/sublength,subfolder(i,1).name);
    if ~isdir(myfilename)
        tmp = strcat(myfilename,'is not a directory');
        msgbox(tmp,'WARN','warn');
        continue
    end
    myfile = dir(myfilename);
    mask.FileName = '';
    mask.WhetherExist = 0;
    foci632.FileName = '';
    foci632.WhetherExist = 0;
    foci535.FileName = '';
    foci535.WhetherExist = 0;  
    foci470.FileName = '';
    foci470.WhetherExist = 0;
    % set the mask file
    for j = 3:length(myfile)
        if ~strcmp(myfile(j,1).name(end-2:end),'tif')
            continue
        end
        if regexp(myfile(j,1).name,'632')
            foci632.FileName = strcat(myfilename,myfile(j,1).name);
            foci632.WhetherExist = 1;
        end
        if regexp(myfile(j,1).name,'535')
            foci535.FileName = strcat(myfilename,myfile(j,1).name);
            foci535.WhetherExist = 1;
        end
        if regexp(myfile(j,1).name,'470')
            foci470.FileName = strcat(myfilename,myfile(j,1).name);
            foci470.WhetherExist = 1;
        end
            
    end
    if regexp(maskmark,'632')
        mask.FileName = foci632.FileName;
        mask.WhetherExist = 1;
    elseif regexp(maskmark,'535')
        mask.FileName = foci535.FileName;
        mask.WhetherExist = 1;
    elseif regexp(maskmark,'470')
        mask.FileName = foci470.FileName;
        mask.WhetherExist = 1;
    end
    mask = FormBWForBatchWork(mask);
    %% update data
%     handles.mask = mask;
%     
%     
%     handles.foci632 = foci632;
%     handles.foci535 = foci535;
%     handles.foci470 = foci470;
%     guidata(hObject,handles);
    
    %% output data
%     mask = handles.mask;
%     foci632 = handles.foci632;
%     foci535 = handles.foci535;
%     foci470 = handles.foci470;
    [mask,foci632,foci535,foci470] = ConstructInfo(mask,foci632,foci535,foci470);
%     handles.mask = mask;
%     handles.foci632 = foci632;
%     handles.foci535 = foci535;
%     handles.foci470 = foci470;
%     guidata(hObject,handles);
%     
%     %% output data
%     mask = handles.mask;
%     foci632 = handles.foci632;
%     foci535 = handles.foci535;
%     foci470 = handles.foci470;
    %% write the focilab window info

    set(handles.txt_outnucleinum,'String',num2str(mask.ObjectNum));
    set(handles.txt_out632focinum,'String',num2str(mask.Foci632Num));
    set(handles.txt_out535focinum,'String',num2str(mask.Foci535Num));
    set(handles.txt_out470focinum,'String',num2str(mask.Foci470Num));
    if mask.ObjectNum ~= 0    
        single632focinum = mask.Single632FociNum;
        single535focinum = mask.Single535FociNum;
        single470focinum = mask.Single470FociNum;
        fraction632 = length(find(single632focinum(:,2)~=0))/mask.ObjectNum;
        fraction535 = length(find(single535focinum(:,2)~=0))/mask.ObjectNum;
        fraction470 = length(find(single470focinum(:,2)~=0))/mask.ObjectNum;
        set(handles.txt_632fraction,'String',num2str(fraction632));
        set(handles.txt_535fraction,'String',num2str(fraction535));
        set(handles.txt_470fraction,'String',num2str(fraction470));
    end
    overlaprg = mask.OverlapRG;
    overlaprb = mask.OverlapRB;
    overlapgb = mask.OverlapGB;
    set(handles.txt_overlapnum632535,'String',num2str(overlaprg(1)));
    set(handles.txt_overlap632535fraction,'String',num2str(overlaprg(2)));
    set(handles.txt_overlapnum632470,'String',num2str(overlaprb(1)));
    set(handles.txt_overlap632470fraction,'String',num2str(overlaprb(2)));
    set(handles.txt_overlapnum535470,'String',num2str(overlapgb(1)));
    set(handles.txt_overlap535470fraction,'String',num2str(overlapgb(2)));
%% output other info to disk
    if OutputMaskInfo(mask)
        disp('Successfully output cell/nuclei file!');
    end
    if OutputFociInfo(foci632)
        disp('Successfully output foci info in wave 632 channel!');
    end
    if OutputFociInfo(foci535)
        disp('Successfully output foci info in wave 535 channel!');
    end
    if OutputFociInfo(foci470)
        disp('Successfully output foci info in wave 470 channel!');
    end
    if OutputImage(mask,foci632,foci535,foci470)
        disp('Successfully output images info!');
    end
    
    %% delete the output memory result
    mask = ClearDataForBatchWork_mask(mask);
    foci632 = ClearDataForBatchWork_foci(foci632);
    foci535 = ClearDataForBatchWork_foci(foci535);
    foci470 = ClearDataForBatchWork_foci(foci470);
end
close(h);
% --- Executes on button press in btn_run.
function btn_run_Callback(hObject, eventdata, handles)
% hObject    handle to btn_run (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

mask = handles.mask;
foci632 = handles.foci632;
foci535 = handles.foci535;
foci470 = handles.foci470;
% output the log file 
[mask,foci632,foci535,foci470] = ConstructInfo(mask,foci632,foci535,foci470);

%% update data
handles.mask = mask;
handles.foci632 = foci632;
handles.foci535 = foci535;
handles.foci470 = foci470;
guidata(hObject,handles);
%% output data
mask = handles.mask;
foci632 = handles.foci632;
foci535 = handles.foci535;
foci470 = handles.foci470;
%% write the focilab window info

set(handles.txt_outnucleinum,'String',num2str(mask.ObjectNum));
set(handles.txt_out632focinum,'String',num2str(mask.Foci632Num));
set(handles.txt_out535focinum,'String',num2str(mask.Foci535Num));
set(handles.txt_out470focinum,'String',num2str(mask.Foci470Num));
if mask.ObjectNum ~= 0    
    single632focinum = mask.Single632FociNum;
    single535focinum = mask.Single535FociNum;
    single470focinum = mask.Single470FociNum;
    fraction632 = length(find(single632focinum(:,2)~=0))/mask.ObjectNum;
    fraction535 = length(find(single535focinum(:,2)~=0))/mask.ObjectNum;
    fraction470 = length(find(single470focinum(:,2)~=0))/mask.ObjectNum;
    set(handles.txt_632fraction,'String',num2str(fraction632));
    set(handles.txt_535fraction,'String',num2str(fraction535));
    set(handles.txt_470fraction,'String',num2str(fraction470));
end
overlaprg = mask.OverlapRG;
overlaprb = mask.OverlapRB;
overlapgb = mask.OverlapGB;
set(handles.txt_overlapnum632535,'String',num2str(overlaprg(1)));
set(handles.txt_overlap632535fraction,'String',num2str(overlaprg(2)));
set(handles.txt_overlapnum632470,'String',num2str(overlaprb(1)));
set(handles.txt_overlap632470fraction,'String',num2str(overlaprb(2)));
set(handles.txt_overlapnum535470,'String',num2str(overlapgb(1)));
set(handles.txt_overlap535470fraction,'String',num2str(overlapgb(2)));


%% output other info to disk
if OutputMaskInfo(mask)
    disp('Successfully output cell/nuclei file!');
end
if OutputFociInfo(foci632)
    disp('Successfully output foci info in wave 632 channel!');
end
if OutputFociInfo(foci535)
    disp('Successfully output foci info in wave 535 channel!');
end
if OutputFociInfo(foci470)
    disp('Successfully output foci info in wave 470 channel!');
end
if OutputImage(mask,foci632,foci535,foci470)
    disp('Successfully output images info!');
end

handles.mask = ClearMaskData(mask);
handles.foci632 = ClearFociData(foci632);
handles.foci535 = ClearFociData(foci535);
handles.foci470 = ClearFociData(foci470);
guidata(hObject,handles);
InitializeInterface(handles)


% --- Executes on button press in checkbox7.
function checkbox7_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox7



function edt_overlap632535_Callback(hObject, eventdata, handles)
% hObject    handle to edt_overlap632535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_overlap632535 as text
%        str2double(get(hObject,'String')) returns contents of edt_overlap632535 as a double
if isempty(get(hObject,'String'))
    msgbox('foci distance can not be null');
    set(hObject,'String',1);
end
dis = round(str2double(get(hObject,'String')));
mask = handles.mask;
mask.OverlapDistanceRG = dis;
handles.mask = mask;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function edt_overlap632535_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_overlap632535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox8.
function checkbox8_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox8



function edt_overlap632470_Callback(hObject, eventdata, handles)
% hObject    handle to edt_overlap632470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_overlap632470 as text
%        str2double(get(hObject,'String')) returns contents of edt_overlap632470 as a double
if isempty(get(hObject,'String'))
    msgbox('foci distance can not be null');
    set(hObject,'String',1);
end
dis = round(str2double(get(hObject,'String')));
mask = handles.mask;
mask.OverlapDistanceRB = dis;
handles.mask = mask;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function edt_overlap632470_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_overlap632470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox9.
function checkbox9_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox9



function edt_overlap535470_Callback(hObject, eventdata, handles)
% hObject    handle to edt_overlap535470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_overlap535470 as text
%        str2double(get(hObject,'String')) returns contents of edt_overlap535470 as a double
if isempty(get(hObject,'String'))
    msgbox('foci distance can not be null');
    set(hObject,'String',1);
end
dis = round(str2double(get(hObject,'String')));
mask = handles.mask;
mask.OverlapDistanceGB = dis;
handles.mask = mask;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function edt_overlap535470_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_overlap535470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edt_maskfile_Callback(hObject, eventdata, handles)
% hObject    handle to edt_maskfile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_maskfile as text
%        str2double(get(hObject,'String')) returns contents of edt_maskfile as a double
file = get(hObject,'String');
mask = handles.mask;
if isempty(file)
    mask.FileName = '';
    mask.WhetherExist = 0;
    mask.BW = 'no_mask';
else 
    mask.FileName = file;
    mask.WhetherExist = 1;
end
handles.mask = mask;
guidata(hObject,handles);
% --- Executes during object creation, after setting all properties.
function edt_maskfile_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_maskfile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btn_maskfileopen.
function btn_maskfileopen_Callback(hObject, eventdata, handles)
% hObject    handle to btn_maskfileopen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%handles.filepath = cd;
[filename,pathname] = uigetfile({'*.tif';'*.jpg';'*.bmp'},...
                                 'select an image',...
                                 handles.filepath);
if filename == 0
    set(handles.edt_maskfile,'String','');
    msgbox('You choose nothing','WARN','warn');
    return
end
set(handles.edt_maskfile,'String',strcat(pathname,filename));
mask = handles.mask;
mask.FileName = strcat(pathname,filename); % set the mask file name
mask.WhetherExist = 1; % whether exists mask file
type = class(imread(mask.FileName)); % set mask.SaturatedIntensity
switch type
    case 'uint8'
        mask.SaturatedIntensity = 255;
    case 'uint16'
        mask.SaturatedIntensity = 4095;
end

handles.mask = mask;
handles.filepath = pathname; %save the file path
guidata(hObject,handles);

% --- Executes on button press in btn_maskfileshow.
function btn_maskfileshow_Callback(hObject, eventdata, handles)
% hObject    handle to btn_maskfileshow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

mask = handles.mask;
if isempty(mask.FileName)
    msgbox('This file is null');
    return;
else
    figure,imagesc(imread(mask.FileName));
    colormap(gray);
end

% --- Executes on button press in btn_maskfilebwshow.
function btn_maskfilebwshow_Callback(hObject, eventdata, handles)
% hObject    handle to btn_maskfilebwshow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

mask = handles.mask;
if mask.WhetherExist == 0
    msgbox('This file is null','WARN','warn');
    return;
end
img = imread(mask.FileName);
switch mask.ObjectFindingMethod
    case 'Otsu'
        bw = MaskfileToBW(img,0);
end
% whether keep the reasonable object
area_below = mask.DeleteObjectBelow;
if ~isempty(area_below)
    bw = DeleteObjectBelow(bw,area_below(1),area_below(2));
end
% whether remove the marginal object
if mask.DeleteMarginalObject == 1
    bw = DeleteMarginalObject(bw);
end
mask.BW = bw;
handles.mask = mask;
guidata(hObject,handles);
figure,imshow(mask.BW);


% --- Executes on button press in chk_maskfileremovearea.
function chk_maskfileremovearea_Callback(hObject, eventdata, handles)
% hObject    handle to chk_maskfileremovearea (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_maskfileremovearea
mask = handles.mask;
if get(hObject,'Value') == 1
    set(handles.edt_maskfileareabelow,'Enable','on');
    set(handles.edt_maskfileareagreat,'Enable','on');
    mask.DeleteObjectBelow =[0 0];
    handles.mask = mask;
    guidata(hObject,handles);
end
if get(hObject,'Value') == 0
    set(handles.edt_maskfileareabelow,'Enable','off','String','');
    set(handles.edt_maskfileareagreat,'Enable','off','String','');
    mask.DeleteObjectBelow =[0 0];
    handles.mask = mask;
    guidata(hObject,handles);
end



function edt_maskfileareabelow_Callback(hObject, eventdata, handles)
% hObject    handle to edt_maskfileareabelow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_maskfileareabelow as text
%        str2double(get(hObject,'String')) returns contents of edt_maskfileareabelow as a double
if isempty(get(hObject,'String'))
    objectbelow1 = 0;
else
    objectbelow1 = round(str2double(get(hObject,'String')));
end
mask = handles.mask;
tmp = mask.DeleteObjectBelow;

tmp = [objectbelow1 tmp(2)];

mask.DeleteObjectBelow = tmp;
handles.mask = mask;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function edt_maskfileareabelow_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_maskfileareabelow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edt_maskfileareagreat_Callback(hObject, eventdata, handles)
% hObject    handle to edt_maskfileareagreat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_maskfileareagreat as text
%        str2double(get(hObject,'String')) returns contents of edt_maskfileareagreat as a double
if isempty(get(hObject,'String'))
    objectbelow2 = 0;
else
    objectbelow2 = round(str2double(get(hObject,'String')));
end
mask = handles.mask;
tmp = mask.DeleteObjectBelow;
tmp = [tmp(1) objectbelow2];
mask.DeleteObjectBelow = tmp;
handles.mask = mask;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function edt_maskfileareagreat_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_maskfileareagreat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in chk_maskfilemarginal.
function chk_maskfilemarginal_Callback(hObject, eventdata, handles)
% hObject    handle to chk_maskfilemarginal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_maskfilemarginal
mask = handles.mask;
if get(hObject,'Value') == 0
    mask.DeleteMarginalObject = 0;
end
if get(hObject,'Value') == 1
    mask.DeleteMarginalObject = 1;
end
handles.mask = mask;
guidata(hObject,handles);

% --- Executes on selection change in pop_maskfilemethod.
function pop_maskfilemethod_Callback(hObject, eventdata, handles)
% hObject    handle to pop_maskfilemethod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns pop_maskfilemethod contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pop_maskfilemethod
mask = handles.mask;
method = get(hObject,'String');
switch method{get(hObject,'Value')}
    case 'Otsu'
        mask.ObjectFindingMethod = 'Otsu';
    case 'contour level'
        mask.ObjectFindingMethod = 'contour level';
end
handle.mask = mask;
guidata(hObject,handles);
% --- Executes during object creation, after setting all properties.
function pop_maskfilemethod_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pop_maskfilemethod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edt_wavefile_Callback(hObject, eventdata, handles)
% hObject    handle to edt_wavefile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_wavefile as text
%        str2double(get(hObject,'String')) returns contents of edt_wavefile as a double
val = get(handles.pop_wave,'Value');
wave = get(handles.pop_wave,'String');
file = get(hObject,'String');
switch wave{val}
    case 'wave632'
        foci = handles.foci632;
        if isempty(file)
            foci.FileName = '';
            foci.WhetherExist = 0;
        else
            foci.FileName = file;
            foci.WhetherExist = 1;
        end
        handles.foci632 = foci;
    case 'wave535'
        foci = handles.foci535;
        if isempty(file)
            foci.FileName = '';
            foci.WhetherExist = 0;
        else
            foci.FileName = file;
            foci.WhetherExist = 1;
        end
        handles.foci535 = foci;
    case 'wave470'
        foci = handles.foci470;
         if isempty(file)
            foci.FileName = '';
            foci.WhetherExist = 0;
        else
            foci.FileName = file;
            foci.WhetherExist = 1;
         end
        handles.foci470 = foci;
end
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function edt_wavefile_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_wavefile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btn_waveopen.
function btn_waveopen_Callback(hObject, eventdata, handles)
% hObject    handle to btn_waveopen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%handles.filepath = cd;
[filename,pathname] = uigetfile({'*.tif';'*.jpg';'*.bmp'},...
                                 'select an image',...
                                 handles.filepath);
if filename == 0
    set(handles.edt_wavefile,'String','');
    msgbox('You choose nothing','WARN','warn');
    return
end
set(handles.edt_wavefile,'String',strcat(pathname,filename));                             
handles.filepath = pathname;

% test it belongs to which channel
% set the foci filename
val = get(handles.pop_wave,'Value');
wave = get(handles.pop_wave,'String');
switch wave{val}
    case 'wave632'
            foci = handles.foci632;
            foci.FileName = strcat(pathname,filename);
            foci.WhetherExist = 1;
            handles.foci632 = foci;
    case 'wave535'
            foci = handles.foci535;
            foci.FileName = strcat(pathname,filename);
            foci.WhetherExist = 1;
            handles.foci535 = foci;
        
    case 'wave470'
            foci = handles.foci470;
            foci.FileName = strcat(pathname,filename);
            foci.WhetherExist =1;
            handles.foci470 = foci;
end


guidata(hObject,handles);

function edt_wavetimes_Callback(hObject, eventdata, handles)
% hObject    handle to edt_wavetimes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_wavetimes as text
%        str2double(get(hObject,'String')) returns contents of edt_wavetimes as a double
std = str2double(get(hObject,'String'));
val = get(handles.pop_wave,'Value');
wave = get(handles.pop_wave,'String');
switch wave{val}
    case 'wave632'
        foci = handles.foci632;
        foci.TimesStd = std;
        handles.foci632 = foci;
    case 'wave535'
        foci = handles.foci535;
        foci.TimesStd = std;
        handles.foci535 = foci;
    case 'wave470'
        foci = handles.foci470;
        foci.TimesStd = std;
        handles.foci470 = foci;
end
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function edt_wavetimes_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_wavetimes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btn_waveshowgrad.
function btn_waveshowgrad_Callback(hObject, eventdata, handles)
% hObject    handle to btn_waveshowgrad (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

val = get(handles.pop_wave,'Value');
wave = get(handles.pop_wave,'String');
mask = handles.mask;
switch wave{val}
    case 'wave632'
        foci = handles.foci632;
    case 'wave535'
        foci =  handles.foci535;
    case 'wave470'
        foci = handles.foci470;
end
% compute the gradline and curve fit line
        if foci.WhetherExist == 0
            msgbox('No file in this channel.','WARN','warn');
            return;
        else
            img = imread(foci.FileName);
            [bw,gradx,grady] = GetFoci(img,mask.BW,foci.TimesStd,foci.MinimumCut);
            grad_cutoff = GetCutoffValue(gradx,grady,foci.TimesStd);
            figure('Name','grad distribution','NumberTitle','off','Color',[0.231 0.443 0.337]),curvefit(gradx,grady);
            hold on
            cutoffx = linspace(grad_cutoff,grad_cutoff,max(grady));
            cutoffy = linspace(1,max(grady),max(grady));
            line(cutoffx,cutoffy,'LineStyle','--','Color','r');
            text(grad_cutoff,max(grady)/3,['cutoff:' num2str(foci.TimesStd) 'std'],'Color','r');
            if foci.MinimumCut ~=0
                minix = linspace(foci.MinimumCut,foci.MinimumCut,max(grady));
                miniy = linspace(1,max(grady),max(grady));
                line(minix,miniy,'LineStyle','-','Color','c');
                text(foci.MinimumCut,max(grady)/2,'minimum cutoff','Color','c')
            end
            hold off
        end



% --- Executes on button press in chk_waveminimumcutoff.
function chk_waveminimumcutoff_Callback(hObject, eventdata, handles)
% hObject    handle to chk_waveminimumcutoff (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_waveminimumcutoff
val = get(handles.pop_wave,'Value');
wave = get(handles.pop_wave,'String');

if get(hObject,'Value') == 1 
    set(handles.edt_waveminimumcutoff,'Enable','on');
end
if get(hObject,'Value') == 0
    set(handles.edt_waveminimumcutoff,'String','');
    set(handles.edt_waveminimumcutoff,'Enable','off');
    if strcmp(wave{val},'wave632')
        foci = handles.foci632;
        foci.MinimumCut = 0;
        handles.foci632 = foci;
    end
    if strcmp(wave{val},'wave535')
        foci = handles.foci535;
        foci.MinimumCut = 0;
        handles.foci535 = foci;
    end
    if strcmp(wave{val},'wave470')
        foci = handles.foci470;
        foci.MinimumCut = 0;
        handles.foci470 = foci;
    end
    guidata(hObject,handles);
end


function edt_waveminimumcutoff_Callback(hObject, eventdata, handles)
% hObject    handle to edt_waveminimumcutoff (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_waveminimumcutoff as text
%        str2double(get(hObject,'String')) returns contents of edt_waveminimumcutoff as a double
minicut = round(str2double(get(hObject,'String')));
wave = get(handles.pop_wave,'String');
val = get(handles.pop_wave,'Value');
switch wave{val}
    case 'wave632'
        foci = handles.foci632;
        foci.MinimumCut = minicut;
        handles.foci632 = foci;
    case 'wave535'
        foci = handles.foci535;
        foci.MinimumCut = minicut;
        handles.foci535 = foci;
    case 'wave470'
        foci = handles.foci470;
        foci.MinimumCut = minicut;
        handles.foci470 = foci;
end
guidata(hObject,handles);
% --- Executes during object creation, after setting all properties.
function edt_waveminimumcutoff_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_waveminimumcutoff (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btn_waveshow.
function btn_waveshow_Callback(hObject, eventdata, handles)
% hObject    handle to btn_waveshow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

val = get(handles.pop_wave,'Value');
wave = get(handles.pop_wave,'String');
switch wave{val}
    case 'wave632'
        foci = handles.foci632;
        if isempty(foci.FileName)
            msgbox('this file is null')
            return;
        else
            figure,imagesc(imread(foci.FileName));
            colormap(gray);
        end
    case 'wave535'
        foci = handles.foci535;
        if isempty(foci.FileName)
            msgbox('this file is null')
            return;
        else
            figure,imagesc(imread(foci.FileName));
            colormap(gray);
        end
    case 'wave470'
        foci = handles.foci470;
        if isempty(foci.FileName)
            msgbox('this file is null')
            return;
        else
            figure,imagesc(imread(foci.FileName));
            colormap(gray);
        end
end

% --- Executes on selection change in pop_wavegrad.
function pop_wavegrad_Callback(hObject, eventdata, handles)
% hObject    handle to pop_wavegrad (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns pop_wavegrad contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pop_wavegrad


% --- Executes during object creation, after setting all properties.
function pop_wavegrad_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pop_wavegrad (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in chk_waveremovefoci.
function chk_waveremovefoci_Callback(hObject, eventdata, handles)
% hObject    handle to chk_waveremovefoci (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_waveremovefoci
if get(hObject,'Value') == 1
    set(handles.edt_waveareabelow,'Enable','on');
end
if get(hObject,'Value') == 0
    set(handles.edt_waveareabelow,'String','');
    set(handles.edt_waveareabelow,'Enable','off');
end


function edt_waveareabelow_Callback(hObject, eventdata, handles)
% hObject    handle to edt_waveareabelow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_waveareabelow as text
%        str2double(get(hObject,'String')) returns contents of edt_waveareabelow as a double
focibelow = round(str2double(get(hObject,'String')));
wave = get(handles.pop_wave,'String');
val = get(handles.pop_wave,'Value');
switch wave{val}
    case 'wave632'
        foci = handles.foci632;
        foci.DeleteFociBelow = focibelow;
        handles.foci632 = foci;
    case 'wave535'
        foci = handles.foci535;
        foci.DeleteFociBelow = focibelow;
        handles.foci535 = foci;
    case 'wave470'
        foci = handles.foci470;
        foci.DeleteFociBelow = focibelow;
        handles.foci470 = foci;
end
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function edt_waveareabelow_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_waveareabelow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in chk_waveonlyonefocus.
function chk_waveonlyonefocus_Callback(hObject, eventdata, handles)
% hObject    handle to chk_waveonlyonefocus (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_waveonlyonefocus
val = get(handles.pop_wave,'Value');
wave = get(handles.pop_wave,'String');

if get(hObject,'Value')==1
    switch wave{val}
        case 'wave632'
                foci = handles.foci632;
                foci.OnlyOneFocus = 1;
                handles.foci632 = foci;
        case 'wave535'
                foci = handles.foci535;
                foci.OnlyOneFocus = 1;
                handles.foci535 = foci;
        case 'wave470'
                foci = handles.foci470;
                foci.OnlyOneFocus = 1;
                handles.foci470 = foci;
    end
else
        switch wave{val}
            case 'wave632'
                foci = handles.foci632;
                foci.OnlyOneFocus = 0;
                handles.foci632 = foci;
             case 'wave535'
                foci = handles.foci535;
                foci.OnlyOneFocus = 0;
                handles.foci535 = foci;
             case 'wave470'
                foci = handles.foci470;
                foci.OnlyOneFocus = 0;
                handles.foci470 = foci;
        end
end
guidata(hObject,handles);
% --- Executes on button press in chk_waveintensitycomparison.
function chk_waveintensitycomparison_Callback(hObject, eventdata, handles)
% hObject    handle to chk_waveintensitycomparison (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_waveintensitycomparison
val = get(handles.pop_wave,'Value');
wave = get(handles.pop_wave,'String');
if get(hObject,'Value') == 1
    set(handles.pop_waveintensitycomparison,'Enable','on');
end
if get(hObject,'Value') == 0
    set(handles.pop_waveintensitycomparison,'Enable','off');
    switch wave{val}
        case 'wave632'
            foci = handles.foci632;
            foci.DependentOn = 'self';
            handles.foci632 = foci;
        case 'wave535'
            foci = handles.foci535;
            foci.DependentOn = 'self';
            handles.foci535 = foci;
        case 'wave470'
            foci = handles.foci470;
            foci.DependentOn = 'self';
            handles.foci470 = foci;
    end
    guidata(hObject,handles);
end

% --- Executes on button press in btn_wavecrop.
function btn_wavecrop_Callback(hObject, eventdata, handles)
% hObject    handle to btn_wavecrop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

mytitle = get(hObject,'String');

val = get(handles.pop_wave,'Value');
wave = get(handles.pop_wave,'String');

switch wave{val}
    case 'wave632'
        foci = handles.foci632;
        if strcmp(mytitle,'crop image')
            if foci.WhetherExist == 0
                msgbox('The file in this channel doesn''t exists.','WARN','warn');
                return;
            end
            %disp(foci.FileName);
            rect = GetCropRect(foci.FileName);
            close gcf
            if ~isempty(rect)
                foci.WhetherRemoveRect = 1;
                foci.RemoveRect = rect;
                set(hObject,'String','delete crop');
                handles.foci632 = foci;
                guidata(hObject,handles);
            end
        end
        if strcmp(mytitle,'delete crop')
            foci.WhetherRemoveRect = 0;
            foci.RemoveRect = [0 0 0 0];
            handles.foci632 = foci;
            guidata(hObject,handles);
            set(hObject,'String','crop image');
        end
        %disp(foci.WhetherRemoveRect)

    case 'wave535'
        foci = handles.foci535;
        
        if strcmp(mytitle,'crop image')
            if foci.WhetherExist == 0
                disp(foci.WhetherExist)
                msgbox('The file in this channel doesn''t exists.','WARN','warn');
                return;
            end
            %disp(foci.FileName);
            rect = GetCropRect(foci.FileName);
            close gcf
            if ~isempty(rect)
                foci.WhetherRemoveRect = 1;
                foci.RemoveRect = [rect(1) rect(2) rect(3) rect(4)];
                set(hObject,'String','delete crop');
            end
        end
        if strcmp(mytitle,'delete crop')
            foci.WhetherRemoveRect = 0;
            foci.RemoveRect = [0 0 0 0];
            set(hObject,'String','crop image');
        end
        %disp(foci.WhetherRemoveRect)
        handles.foci535 = foci;
        guidata(hObject,handles);
    case 'wave470'
        foci = handles.foci470;
        if strcmp(mytitle,'crop image')
            if foci.WhetherExist == 0
                msgbox('The file in this channel doesn''t exists.','WARN','warn');
                return;
            end
            %disp(foci.FileName);
            rect = GetCropRect(foci.FileName);
            close gcf
            if ~isempty(rect)
                foci.WhetherRemoveRect = 1;
                foci.RemoveRect = [rect(1) rect(2) rect(3) rect(4)];
                set(hObject,'String','delete crop');
            end
        end
        if strcmp(mytitle,'delete crop')
            foci.WhetherRemoveRect = 0;
            foci.RemoveRect = [0 0 0 0];
            set(hObject,'String','crop image');
        end
        disp(foci.WhetherRemoveRect)
        handles.foci470 = foci;
        guidata(hObject,handles);
end

% --- Executes on button press in btn_wavecropshow.
function btn_wavecropshow_Callback(hObject, eventdata, handles)
% hObject    handle to btn_wavecropshow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

val = get(handles.pop_wave,'Value');
wave = get(handles.pop_wave,'String');
switch wave{val}
    case 'wave632'
        foci = handles.foci632;        
    case 'wave535'
        foci = handles.foci535;
    case 'wave470'
        foci = handles.foci470;
end
if foci.WhetherRemoveRect == 0
    msgbox('you have not the cropped image in this channle.','WARN','warn');
    return;
else
    img = imread(foci.FileName);
    figure,imagesc(img);
    colormap(gray);
    hold on
    disp(foci.RemoveRect);
    rectangle('Position',foci.RemoveRect,'EdgeColor','y');
    hold off
end

% --- Executes on button press in rad_waveobjectcentroid.
function rad_waveobjectcentroid_Callback(hObject, eventdata, handles)
% hObject    handle to rad_waveobjectcentroid (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rad_waveobjectcentroid
if get(hObject,'Value') == 1
%     set(hObject,'Value',1);
    
    set(handles.rad_waveweightedcentroid,'Value',0);
    val = get(handles.pop_wave,'Value');
    wave = get(handles.pop_wave,'String');
    switch wave{val}
        case 'wave632'
            foci = handles.foci632;
            foci.DefineCenter = 'object centroid';
            handles.foci632 = foci;
        case 'wave535'
            foci = handles.foci535;
            foci.DefineCenter = 'object centroid';
            handles.foci535 = foci;
        case 'wave470'
            foci = handles.foci470;
            foci.DefineCenter = 'object centroid';
            handles.foci470 = foci;          
    end
    disp('you choose object centroid.');
end
if get(hObject,'Value') == 0
    set(hObject,'Value',1);
    set(handles.rad_waveweightedcentroid,'Value',0); 
end
guidata(hObject,handles);

% --- Executes on button press in rad_waveweightedcentroid.
function rad_waveweightedcentroid_Callback(hObject, eventdata, handles)
% hObject    handle to rad_waveweightedcentroid (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rad_waveweightedcentroid
if get(hObject,'Value') == 1
%     set(hObject,'Value',1);
    
    set(handles.rad_waveobjectcentroid,'Value',0);
    val = get(handles.pop_wave,'Value');
    wave = get(handles.pop_wave,'String');
    switch wave{val}
        case 'wave632'
            foci = handles.foci632;
            foci.DefineCenter = 'weighted centroid';
            handles.foci632 = foci;
        case 'wave535'
            foci = handles.foci535;
            foci.DefineCenter = 'weighted centroid';
            handles.foci535 = foci;
        case 'wave470'
            foci = handles.foci470;
            foci.DefineCenter = 'weighted centroid';
            handles.foci470 = foci;          
    end
    disp('you choose weighted centroid.');
end
if get(hObject,'Value') == 0 
    set(hObject,'Value',1);
    set(handles.rad_waveobjectcentroid,'Value',0); 

end
guidata(hObject,handles);

% --- Executes on selection change in pop_waveintensitycomparison.
function pop_waveintensitycomparison_Callback(hObject, eventdata, handles)
% hObject    handle to pop_waveintensitycomparison (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns pop_waveintensitycomparison contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pop_waveintensitycomparison
valthis = get(hObject,'Value');
wavethis = get(hObject,'String');
val = get(handles.pop_wave,'Value');
wave = get(handles.pop_wave,'String');
switch wave{val}
    case 'wave632'
        foci = handles.foci632;
        if strcmp(wavethis{valthis},'wave632');
            foci.DependentOn = 'self';
        elseif strcmp(wavethis{valthis},'wave535');
            foci.DependentOn = 'wave535';
        elseif strcmp(wavethis{valthis},'wave470');
            foci.DependentOn = 'wave470';
        end
        handles.foci632 = foci;
    case 'wave535'
        foci = handles.foci535;
        if strcmp(wavethis{valthis},'wave632');
            foci.DependentOn = 'wave632';
        elseif strcmp(wavethis{valthis},'wave535');
            foci.DependentOn = 'self';
        elseif strcmp(wavethis{valthis},'wave470');
            foci.DependentOn = 'wave470';
        end
        handles.foci535 = foci;    
    case 'wave470'
         foci = handles.foci470;
        if strcmp(wavethis{valthis},'wave632');
            foci.DependentOn = 'wave632';
        elseif strcmp(wavethis{valthis},'wave535');
            foci.DependentOn = 'wave535';
        elseif strcmp(wavethis{valthis},'wave470');
            foci.DependentOn = 'self';
        end
        handles.foci470 = foci;       
end
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function pop_waveintensitycomparison_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pop_waveintensitycomparison (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btn_close.
function btn_close_Callback(hObject, eventdata, handles)
% hObject    handle to btn_close (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

questbutton = questdlg('Do you really want to quit?','Close','Yes','No','Yes');
if strcmp(questbutton,'Yes')
    delete(handles.figure1);
end

function ShowWaveData(foci,handles)
% foci is foci struct;
set(handles.edt_wavefile,'String',foci.FileName);
if strcmp(foci.ParticleFindingMethod,'grad info')
    set(handles.pop_wavegrad,'String','grad info');
    set(handles.edt_wavetimes,'String',foci.TimesStd);
    if foci.MinimumCut ~= 0
        set(handles.chk_waveminimumcutoff,'Value',1);
        set(handles.edt_waveminimumcutoff,'String',foci.MinimumCut);
    else 
        set(handles.chk_waveminimumcutoff,'Value',0);
        set(handles.edt_waveminimumcutoff,'String','');
        set(handles.edt_waveminimumcutoff,'Enable','off');        
    end
end
switch foci.DefineCenter
    case 'object centroid'
        set(handles.rad_waveobjectcentroid,'Value',1);
        set(handles.rad_waveweightedcentroid,'Value',0);
    case 'weighted centroid'
        set(handles.rad_waveobjectcentroid,'Value',0);
        set(handles.rad_waveweightedcentroid,'Value',1);
end
if foci.DeleteFociBelow ~= 0
    set(handles.chk_waveremovefoci,'Value',1);
    set(handles.edt_waveareabelow,'String',foci.DeleteFociBelow);
else
    set(handles.chk_waveremovefoci,'Value',0);    
    set(handles.edt_waveareabelow,'String','');
    set(handles.edt_waveareabelow,'Enable','off');
end
if foci.OnlyOneFocus == 0
    set(handles.chk_waveonlyonefocus,'Value',0);
else
    set(handles.chk_waveonlyonefocus,'Value',1);
end
if strcmp(foci.DependentOn,'self')
    set(handles.chk_waveintensitycomparison,'Value',0);
    set(handles.pop_waveintensitycomparison,'Enable','off');
else
    set(handles.chk_waveintensitycomparison,'Value',1);
    if strcmp(foci.DependentOn,'wave632')
        set(handles.pop_waveintensitycomparison,'String',[{'wave632'};{'wave535'};{'wave470'}],'Value',1);
    elseif strcmp(foci.DependentOn,'wave535')
        set(handles.pop_waveintensitycomparison,'String',[{'wave535'};{'wave632'};{'wave470'}],'Value',1);
    elseif strcmp(foci.DependentOn,'wave470')
        set(handles.pop_waveintensitycomparison,'String',[{'wave470'};{'wave632'};{'wave535'}],'Value',1);
    end
end
if foci.WhetherRemoveRect == 0
    set(handles.btn_wavecrop,'String','crop image');
else
    set(handles.btn_wavecrop,'String','delete image');
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

questbutton = questdlg('Do you really want to quit?','Close','Yes','No','Yes');
if strcmp(questbutton,'Yes')
    delete(hObject);
end

function rect = GetCropRect(filename)
% get the cropped rectangle

rect =[];
img = imread(filename);
figure,imagesc(img)
colormap(gray)
[cropimg,rect] = imcrop;

function mask = ClearMaskData(mask)
% clear mask content when the finish a run

mask.FileName = '';
mask.WhetherExist = 0;
mask.ObjectFindingMethod = 'Otsu';
mask.DeleteObjectBelow =[0 0];
mask.DeleteMarginalObject =0;
mask.Centroid =[];
mask.Area = [];
mask.Perimeter = [];
mask.Intensity = [];
mask.BoundingBox = [];
mask.Single632FociNum = [];
mask.Single535FociNum = [];
mask.Single470FociNum = [];
mask.Single632535Num = [];
mask.Single632470Num =[];
mask.Single535470Num =[];
mask.Foci632Num = 0;
mask.Foci535Num = 0;
mask.Foci470Num = 0;
mask.OverlapRG = [0 0]; %have two data,the first is overlap num;the second is correlation
mask.OverlapRB = [0 0]; %the same to above
mask.OverlapGB = [0 0]; %the same to above
mask.OverlapDistanceRG = 1;
mask.OverlapDistanceRB = 1;
mask.OverlapDistanceGB = 1;
mask.ObjectNum = 0;
mask.CorrIntensity = 'MaxIntensity';
mask.SaturatedIntensity = 4095;
mask.BW = 'no_mask';


function foci = ClearFociData(foci)
% clear foci content when finish a run

foci.FileName = '';
foci.WhetherExist = 0;
foci.ParticleFindingMethod = 'grad info';
foci.TimesStd = 3;
foci.FitLine = [];
foci.ContourLevel=2;
foci.MinimumCut = 200;
foci.WhetherRemoveRect = 0;
foci.RemoveRect = [0 0 0 0];
foci.DefineCenter = 'object centroid';
foci.DeleteFociBelow = 0;
foci.OnlyOneFocus = 0;
foci.DependentOn = 'self';
foci.DependentIntensity = [];
foci.Centroid =[];
foci.Area = [];
foci.Perimeter = [];
foci.Intensity = [];
foci.NucleiId =[];
foci.OverlapWithFoci1 = [];
foci.OverlapWithFoci2 = [];
foci.BW = [];


function InitializeInterface(handles)
% initialize the software interface

set(handles.edt_wavefile,'String','');
set(handles.edt_maskfile,'String','');
%set the radio button for choosing the centroid option
set(handles.rad_waveobjectcentroid,'Value',1);
set(handles.rad_waveweightedcentroid,'Value',0);
% set mask option button
set(handles.chk_maskfileremovearea,'Value',0);
set(handles.edt_maskfileareabelow,'Enable','off','String','');
set(handles.edt_maskfileareagreat,'Enable','off','String','');
set(handles.chk_maskfilemarginal,'Value',0)

% set the wave additional option
set(handles.btn_wavecrop,'String','crop image');
set(handles.chk_waveremovefoci,'Value',0);
set(handles.edt_waveareabelow,'Enable','off','String','');
set(handles.chk_waveonlyonefocus,'Value',0);
set(handles.chk_waveintensitycomparison,'Value',0);
set(handles.pop_waveintensitycomparison,'Enable','off');
set(handles.edt_wavetimes,'String',3);
set(handles.chk_waveminimumcutoff,'Value',1);
set(handles.edt_waveminimumcutoff,'String',200,'Enable','on');
% set overlap distance setting
set(handles.edt_overlap632535,'String',1);
set(handles.edt_overlap632470,'String',1);
set(handles.edt_overlap535470,'String',1);


function mask = ClearDataForBatchWork_mask(mask)
% clear data for mask

mask.Centroid = [];
mask.Area = [];
mask.Perimeter = [];
mask.Intensity = [];
mask.BoundingBox = [];
mask.Single632FociNum = [];
mask.Single535FociNum = [];
mask.Single470FociNum = [];
mask.Single632535Num = [];
mask.Single632470Num = [];
mask.Single535470Num = [];
mask.Foci632Num = 0;
mask.Foci535Num = 0;
mask.Foci470Num = 0;
mask.OverlapRG = [0 0];
mask.OverlapRB = [0 0];
mask.OverlapGB = [0 0];
mask.ObjectNum = 0;
mask.BW = 'no_mask';

function foci = ClearDataForBatchWork_foci(foci)
% clear foci memory data

foci.DependentIntensity = [];
foci.Centroid = [];
foci.Area = [];
foci.Perimeter = [];
foci.Intensity = [];
foci.NucleiId = [];
foci.OverlapWithFoci1 = [];
foci.OverlapWithFoci2 = [];
foci.BW = [];

function mask = FormBWForBatchWork(mask)
% form a bw mask for batch work

if mask.WhetherExist == 0
    return;
end
img = imread(mask.FileName);
switch mask.ObjectFindingMethod
    case 'Otsu'
        bw = MaskfileToBW(img,0);
end
% whether keep the reasonable object
area_below = mask.DeleteObjectBelow;
if ~isempty(area_below)
    bw = DeleteObjectBelow(bw,area_below(1),area_below(2));
end
% whether remove the marginal object
if mask.DeleteMarginalObject == 1
    bw = DeleteMarginalObject(bw);
end
mask.BW = bw;
handles.mask = mask;
