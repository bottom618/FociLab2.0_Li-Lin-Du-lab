function s = GetBWRegionProp(img,bw,prop)
% get bw image the property

img = double(img);
if size(img,1) ~=size(bw,1) || size(img,2) ~= size(bw,2)
    error('the size of image and binary image are not same.');
end
lab = bwlabel(bw);
switch prop
    case 'area'
        d = regionprops(lab,'Area');
        s = zeros(length(d),2);
        for i = 1:length(d)
            s(i,1) = i;
            s(i,2) = d(i,1).Area;
        end
    case 'object centroid'
        d = regionprops(lab,'Centroid');
        s = zeros(length(d),3);
        for i = 1:length(d)
            s(i,1) = i;
            s(i,2) = d(i,1).Centroid(1);
            s(i,3) = d(i,1).Centroid(2);
        end
    case 'perimeter'
        d = regionprops(lab,'perimeter');
        s = zeros(length(d),2);
        for i = 1:length(d)
            s(i,1) = i;
            s(i,2) = d(i,1).Perimeter;
        end
    case 'intensity'
        d = regionprops(lab,img,'MaxIntensity','MeanIntensity','MinIntensity');
        s = zeros(length(d),4);
        for i = 1:length(d)
            s(i,1) = i;
            s(i,2) = d(i,1).MaxIntensity;
            s(i,3) = d(i,1).MeanIntensity;
            s(i,4) = d(i,1).MinIntensity;
        end
    case 'boundingbox'
        d = regionprops(lab,'BoundingBox');
        s = zeros(length(d),5);
        for i = 1:length(d)
            s(i,1) = i;
            s(i,2) = d(i,1).BoundingBox(1);
            s(i,3) = d(i,1).BoundingBox(2);
            s(i,4) = d(i,1).BoundingBox(3);
            s(i,5) = d(i,1).BoundingBox(4);
        end
    case 'weighted centroid'
        d = regionprops(lab,img,'WeightedCentroid');
        s = zeros(length(d),3);
        for i = 1:length(d)
            s(i,1) = i;
            s(i,2) = d(i,1).WeightedCentroid(1);
            s(i,3) = d(i,1).WeightedCentroid(2);
        end
    case 'major axis length'
        d = regionprops(lab,img,'MajorAxisLength');
        s = zeros(length(d),2);
        for i = 1:length(d)
            s(i,1) = i;
            s(i,2) = d(i,1).MajorAxisLength;
        end
    case 'minor axis length'
        d = regionprops(lab,img,'MinorAxisLength');
        s = zeros(length(d),2);
        for i = 1:length(d)
            s(i,1) = i;
            s(i,2) = d(i,1).MinorAxisLength;
        end
    otherwise 
        disp('Have no this property.');
end