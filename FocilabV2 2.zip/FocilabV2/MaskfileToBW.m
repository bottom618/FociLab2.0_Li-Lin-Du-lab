function bw_inner = MaskfileToBW(img,method)
% This function is used to get bw image from maskfile.
% maskfile is not only uint8 but also is uint16.
% bw is the logical file.

classin = class(img);
if ~(strcmp(classin,'uint8') || strcmp(classin,'uint16') || strcmp(classin,'double')) 
        error('Unknown or improper image class.');
end

% adjust image
img = imadjust(img,stretchlim(img,[0.01 0.999]),[]);
bw = GetBimask(img,method);
bw = bwmorph(bw,'fill');
bw = bwmorph(bw,'majority');
bw = bwmorph(bw,'clean');
bw = bwmorph(bw,'spur');
bw = bwmorph(bw,'hbreak');
%bw = bwmorph(bw,'dilate');
%bw = bwmorph(bw,'dilate');
% [bw_inner,inner_ed] = DeleteObjectInBorder(bw);
bw_inner = bw;