function gmatrix = TotalImgGrad(img)
% get grads for the total image

img = double(img);
[M,N] = size(img);
gmatrix = zeros(M,N);
GL = 2;    % the grad length
temp = padarray(img,[GL GL],'replicate');
[TM,TN] = size(temp);
for r = GL+1:TM-GL
    for c = GL+1:TN-GL
        grad = temp(r,c)*8 -temp(r-GL,c-GL) - temp(r-GL,c) - temp(r-GL,c+GL)...
                           -temp(r,c-GL) - temp(r,c+GL)...
                           -temp(r+GL,c-GL) - temp(r+GL,c) - temp(r+GL,c+GL);
         gmatrix(r,c) = grad;
    end
end
gmatrix = gmatrix(GL+1:TM-GL,GL+1:TN-GL);