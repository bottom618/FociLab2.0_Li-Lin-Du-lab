function lic = actxlicense(progid)

if strcmpi(progid, 'MSComctlLib.TabStrip.2')
lic = '9368265E-85FE-11d1-8BE3-0000F8754DA1';
return;
end
if strcmpi(progid, 'MSComctlLib.TabStrip.2')
lic = '9368265E-85FE-11d1-8BE3-0000F8754DA1';
return;
end
if strcmpi(progid, 'COMCTL.TabStrip.1')
lic = ' qhj ZtuQha;jdfn[iaetr ';
return;
end
if strcmpi(progid, 'COMCTL.TabStrip.1')
lic = ' qhj ZtuQha;jdfn[iaetr ';
return;
end
if strcmpi(progid, 'MSComctlLib.TabStrip.2')
lic = '9368265E-85FE-11d1-8BE3-0000F8754DA1';
return;
end
if strcmpi(progid, 'MSComctlLib.TabStrip.2')
lic = '9368265E-85FE-11d1-8BE3-0000F8754DA1';
return;
end
if strcmpi(progid, 'MSComctlLib.TabStrip.2')
lic = '9368265E-85FE-11d1-8BE3-0000F8754DA1';
return;
end