function outintensity = DependentIntensity(foci1,foci2,num)
% according to foci1, extract foci2 intensity,even if foci2 have no foci.
% the output format:
% foci1_id maxintensity mean min foci2_max foci2_mean foci2_min overlapid

if num == 1
   overlapfoci = foci1.OverlapWithFoci1;
elseif num == 2
    overlapfoci = foci1.OverlapWithFoci2;
end

intensity1 = foci1.Intensity;
intensity2 = foci2.Intensity;
img2 = double(imread(foci2.FileName));
cen1 = foci1.Centroid;
outintensity = zeros(size(intensity1,1),8);
for i = 1:size(intensity1,1)
    if intensity1(i,1) ~=i
        error('dependent intensity error occur');
    end
    outintensity(i,1) = i;
    outintensity(i,2) = intensity1(i,2);
    outintensity(i,3) = intensity1(i,3);
    outintensity(i,4) = intensity1(i,4);
    if overlapfoci(i,2) ~=0
        foci2id = overlapfoci(i,2);
        outintensity(i,5) = intensity2(foci2id,2);
        outintensity(i,6) = intensity2(foci2id,3);
        outintensity(i,7) = intensity2(foci2id,4);
        outintensity(i,8) = foci2id;
    else
        ceny = cen1(i,2);
        cenx = cen1(i,3);
        inten = ExtractIntensity(cenx,ceny,img2,num);
        outintensity(i,5) = inten(1);
        outintensity(i,6) = inten(2);
        outintensity(i,7) = inten(3);
        outintensity(i,8) = 0;
    end

end

function inten = ExtractIntensity(cenx,ceny,img,num)
% extract the intensity

cenx = round(cenx);
ceny = round(ceny);
[m,n] = size(img);
if cenx-num<1
    row1 = 1;
else 
    row1 = cenx-num;
end
if cenx+num>m
    row2 = m;
else
    row2 = cenx+num;
end
if ceny-num<1
    col1 = 1;
else
    col1 = ceny-num;
end
if ceny+num>n
    col2 = n;
else 
    col2 = ceny+num;
end
    
subimg = img(row1:row2,col1:col2);
maxint = max(subimg(:));
meanint = mean(subimg(:));
minint = min(subimg(:));
inten = round([maxint meanint minint]);
