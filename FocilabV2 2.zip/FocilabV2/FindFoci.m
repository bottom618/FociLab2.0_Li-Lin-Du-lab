function bw = FindFoci(img,method,bw_where,varargin)
% this is used to find foci on the specified image,according to different
% method. For different method, varargin have different parameters.

switch method
    case 'grad info'
        error(nargchk(3,5,nargin));
        if nargin == 3
            cutoff = 3.5;
            minimumcutoff = 0;
        elseif nargin == 4
            cutoff = varargin{1};
            minimumcutoff = 0;
        elseif nargin ==5
            cutoff = varargin{1};
            minimumcutoff = varargin{2};
        end
        bw = GetFoci(img,bw_where,cutoff,minimumcutoff);

        
    case '2D gaussian fit'
    case 'contour level'
        error(nargchk(3,4,nargin));
        if strcmp(bw_where,'no_mask')
            error('contour levle must need mask image.');
        end
        if nargin == 3
            level = 2;
        elseif nargin == 4
            level = varargin{1};
        end
        bw = ContourFoci(img,bw_where,level);
    otherwise 
        error('I don''t kown this method.');
end