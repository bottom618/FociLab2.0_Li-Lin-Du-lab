function bw_inner = DeleteMarginalObject(bw)
% This function is mainly used to wipe off the object inner in the total
% screen.

bw_inner = bw;
[M,N] = size(bw);
[lab_bw,k] = bwlabel(bw);
boundaries = bwboundaries(lab_bw);
u = 0;
contentarray=[];

for i = 1:k
    aux = boundaries{i,1};
    % observe whther this edge of object is in the border of image
    ism = ismember(aux,1) | ismember(aux,M) | ismember(aux,N);
    lg = find(ism == 1);
    if lg >=1
        u = u+1;
        contentarray(u) = i;
    end
end
if isempty(contentarray)
    bw_inner = bw;
else
    for i = contentarray
        [r,c] = find(lab_bw == i);
        for j = 1:length(r)
            bw_inner(r(j),c(j)) = 0;
        end
    end
end
