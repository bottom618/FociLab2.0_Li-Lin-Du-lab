function [mask,foci632,foci535,foci470] = ConstructInfo(mask,foci632,foci535,foci470)

% 
if OutputLogFile(mask,foci632,foci535,foci470)
    disp('Successfully output log file!');
else 
    return;
end
% construct mask 
mask = ConstructMask(mask);
% construct foci
foci632 = ConstructFoci(mask,foci632);
mask.Foci632Num = size(foci632.Centroid,1);
mask.Single632FociNum = EveryNuclei(mask.BW,foci632.Centroid);
foci535 = ConstructFoci(mask,foci535);
mask.Foci535Num = size(foci535.Centroid,1);
mask.Single535FociNum = EveryNuclei(mask.BW,foci535.Centroid);
foci470 = ConstructFoci(mask,foci470);
mask.Foci470Num = size(foci470.Centroid,1);
mask.Single470FociNum = EveryNuclei(mask.BW,foci470.Centroid);

%% ---------------overlap settting-------------
if foci632.WhetherExist == 1 && foci535.WhetherExist == 1
   foci632.OverlapWithFoci1 = OverlapFociId(foci632.Centroid,foci535.Centroid,mask.OverlapDistanceRG);
end
if foci632.WhetherExist == 1 && foci470.WhetherExist == 1
    foci632.OverlapWithFoci2 = OverlapFociId(foci632.Centroid,foci470.Centroid,mask.OverlapDistanceRB);
end
if foci535.WhetherExist == 1 && foci632.WhetherExist == 1
    foci535.OverlapWithFoci1 = OverlapFociId(foci535.Centroid,foci632.Centroid,mask.OverlapDistanceRG);
end
if foci535.WhetherExist == 1 && foci470.WhetherExist == 1
    foci535.OverlapWithFoci2 = OverlapFociId(foci535.Centroid,foci470.Centroid,mask.OverlapDistanceGB);
end
if foci470.WhetherExist == 1 && foci632.WhetherExist == 1
    foci470.OverlapWithFoci1 = OverlapFociId(foci470.Centroid,foci632.Centroid,mask.OverlapDistanceRB);
end
if foci470.WhetherExist == 1 && foci535.WhetherExist == 1
    foci470.OverlapWithFoci2 = OverlapFociId(foci470.Centroid,foci535.Centroid,mask.OverlapDistanceGB);
end

mask.Single632535Num = SingleOverlapNum(mask.BW,foci632.Centroid,foci632.OverlapWithFoci1);
mask.Single632470Num = SingleOverlapNum(mask.BW,foci632.Centroid,foci632.OverlapWithFoci2);
mask.Single535470Num = SingleOverlapNum(mask.BW,foci535.Centroid,foci535.OverlapWithFoci2);

%% compute dependent intensity
% for wave632
if strcmp(foci632.DependentOn,'wave535')
    foci632.DependentIntensity = DependentIntensity(foci632,foci535,1);
elseif strcmp(foci632.DependentOn,'wave470')
    foci632.DependentIntensity = DependentIntensity(foci632,foci470,2);
end
% for wave535
if strcmp(foci535.DependentOn,'wave632')
    foci535.DependentIntensity = DependentIntensity(foci535,foci632,1);
elseif strcmp(foci535.DependentOn,'wave470')
    foci535.DependentIntensity = DependentIntensity(foci535,foci470,2);
end
% for wave470
if strcmp(foci470.DependentOn,'wave632')
    foci470.DependentIntensity = DependentIntensity(foci470,foci632,1);
elseif strcmp(foci470.DependentOn,'wave535')
    foci470.DependentIntensity = DependentIntensity(foci470,foci535,2);
end

%% -------------compute overlap num and corr--------
if foci632.WhetherExist == 1 && foci535.WhetherExist == 1
    [overlapnum,linx632535,liny632535,correlation,spot632,spot535] = OverlapInfo(mask,foci632,foci535,1);
    mask.OverlapRG = [overlapnum,correlation];
end
if foci632.WhetherExist == 1 && foci470.WhetherExist == 1
    [overlapnum,linx632470,liny632470,correlation,spot632,spot470] = OverlapInfo(mask,foci632,foci470,2);
    mask.OverlapRB = [overlapnum,correlation];
end
if foci535.WhetherExist == 1 && foci470.WhetherExist == 1
    [overlapnum,linx535470,liny535470,correlation,spot535,spot470] = OverlapInfo(mask,foci535,foci470,2);
    mask.OverlapGB = [overlapnum,correlation];
end