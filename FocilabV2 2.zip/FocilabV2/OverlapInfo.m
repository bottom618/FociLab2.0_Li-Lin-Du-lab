function [overlapnum,linx,liny,correlation,over1,over2] = OverlapInfo(nuclei,foci1,foci2,num)
% this function is used to output the overlap information,including the
% overlap num between channel 1 and 2.fitline,correlation

if num == 1
    overlapfociid = foci1.OverlapWithFoci1;
elseif num == 2
    overlapfociid = foci1.OverlapWithFoci2;
end
overlapnum = length(find(overlapfociid(:,2)~=0));
intensity1 = foci1.Intensity;
intensity2 = foci2.Intensity;
over1 = zeros(overlapnum,1);
over2 = zeros(overlapnum,1);
switch nuclei.CorrIntensity
    case 'MaxIntensity'
        col = 2;
    case 'MeanIntensity'
        col = 3;
    case 'MinIntensity'
        col = 4;
    otherwise
        error('No this intensity!');
end
n = 1;   
for i = 1:size(overlapfociid,1)
    if overlapfociid(i,2)~=0
        over1(n) = intensity1(i,col);
        over2(n) = intensity2(overlapfociid(i,2),col);
        n = n+1;
    end
end

if nuclei.SaturatedIntensity == 0
    [linx,liny,correlation] = GetSlideD(over1,over2,0,4095);
else
    [linx,liny,correlation] = GetSlideD(over1,over2,1,nuclei.SaturatedIntensity);
end