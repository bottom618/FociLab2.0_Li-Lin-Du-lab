function mark = OutputLogFile(mask,foci632,foci535,foci470)
% this is used to output the parameters settings


if mask.WhetherExist == 1
    file = mask.FileName;
elseif foci632.WhetherExist == 1
    file = foci632.FileName;
elseif foci535.WhetherExist == 1
    file = foci535.FileName;
elseif foci470.WhetherExist == 1
    file = foci470.FileName;
end

blash = regexp(file,'\');

file = strcat(file(1:blash(end)),'logfile_for_',file(blash(end)+1:end-4),'.txt');

fid = fopen(file,'w');
today = strcat('Date:',date);
fprintf(fid,'%s\n\n',today);
if mask.WhetherExist == 0 
    fprintf(fid,'Where to find foci: \t\t%s\n\n','Global');
else 
    fprintf(fid,'Where to find foci: \t\t%s\n',mask.FileName);
    fprintf(fid,'Particle findding method: \t\t%s\n',mask.ObjectFindingMethod);
    tmp = mask.DeleteObjectBelow;
    if tmp(1) == 0 && tmp(2) == 0
        fprintf(fid,'Delete object condition: \t\t%s\n','NO');
    elseif tmp(1) >0 && tmp(2) == 0
        fprintf(fid,'Delete object condition: \t\tarea < %d\n',tmp(1));
    elseif tmp(1) ==0 && tmp(2)>0
        fprintf(fid,'Delete object condition: \t\tarea > %d\n',tmp(2));
    elseif tmp(1)>0 && tmp(2)>0
        fprintf(fid,'Delete object condition: \t\tarea < %d; area > %d\n',tmp(1),tmp(2));
    end
    fprintf(fid,'Correlation for correlation: \t\t%s\n',mask.CorrIntensity);
    fprintf(fid,'Remove the saturated intensity: \t\t%d\n',mask.SaturatedIntensity);
    fprintf(fid,'Overlap distance between 632 and 535 channel: \t\t%d\n',mask.OverlapDistanceRG);
    fprintf(fid,'Overlap distance between 632 and 470 channel: \t\t%d\n',mask.OverlapDistanceRB);
    fprintf(fid,'Overlap distance between 535 and 470 channel: \t\t%d\n\n',mask.OverlapDistanceGB);
end
OutputFociSetting(foci632,fid,'wave 632 channel');
OutputFociSetting(foci535,fid,'wave 535 channel');
OutputFociSetting(foci470,fid,'wave 470 channel');
mark = 1;

fclose(fid);

function OutputFociSetting(foci,h,name)
% output single foci setting

fprintf(h,'\n');
fprintf(h,'*********** %s ************\n',name);
if foci.WhetherExist == 0
    fprintf(h,'FileName: \t\t%s\n','NONE');
else
    fprintf(h,'FileName: \t\t%s\n',foci.FileName);
    fprintf(h,'Particle finding method: \t\t%s\n',foci.ParticleFindingMethod);
    if strcmp(foci.ParticleFindingMethod,'grad info')
        fprintf(h,'Deviation times: \t\t%d\n',foci.TimesStd);
        fprintf(h,'The minimum cutoff is \t\t%d\n',foci.MinimumCut);
    end
    if foci.WhetherRemoveRect == 0
        fprintf(h,'Whether remove some area: \t\t%s\n','NO');
    else
        tmp = foci.RemoveRect;
        fprintf(h,'Whether remove some area: \t\t%s,[%d %d %d %d]\n','YES',round(tmp(2)),round(tmp(1)),round(tmp(3)),round(tmp(4)));
    end
    fprintf(h,'Define center: \t\t%s\n',foci.DefineCenter);
    if strcmp(foci.DependentOn,'self')
        fprintf(h,'Whether extract dependent intensity: \t\t%s\n','NO');
    else
        fprintf(h,'Whether extract dependent intensity: \t\t%s\n',foci.DependentOn);
    end
    if foci.OnlyOneFocus == 0
        fprintf(h,'Whether remain only one focus in every object:\t\t%s\n','NO');
    else
        fprintf(h,'Whether remain only one focus in every object:\t\t%s\n','YES');
    end
    if foci.DeleteFociBelow < 2
        fprintf(h,'Whether remove unqualified foci:\t\t%s\n','NO');
    else
        fociarea = strcat('YES,area<',num2str(foci.DeleteFociBelow));
        fprintf(h,'Whether remove unqualifid foci:\t\t%s\n',fociarea);
    end
end


