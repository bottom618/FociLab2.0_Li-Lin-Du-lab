function foci632 = ConstructFoci(mask,foci632)
% this function is used to construct foci structur. mask and foci632 are
% both struct type. when produce foci632, mask is needed.
% foci structure is below:
% 
% load the wave 632 file
% if ~isempty(foci632.FileName)
%     img_foci632 = imread(foci632.FileName);
%     foci632.WhetherExist = 1;
% else
%     foci632.WhetherExist = 0;
%     return;
% end

if foci632.WhetherExist == 0
    disp('have no this channel!');
    return;
end

img_foci632 = imread(foci632.FileName);

% get the foci binary image
if strcmp(foci632.ParticleFindingMethod,'grad info')
    bw_foci632 = FindFoci(img_foci632,foci632.ParticleFindingMethod,mask.BW,foci632.TimesStd,foci632.MinimumCut);
elseif strcmp(foci632.ParticleFindingMethod,'contour level')
    bw_foci632 = FindFoci(img_foci632,foci632.ParticleFindingMethod,mask.BW,foci632.ContourLevel);
end
% whether remove the brighter area
if foci632.WhetherRemoveRect
    %figure,imagesc(img_foci632)
    %colormap(gray);
    %[I,rect] = imcrop;
    %foci632.RemoveRect = rect;
    bw_foci632 = RemoveFociInRect(bw_foci632,foci632.RemoveRect);
end
% whether need to remove foci below 1
if foci632.DeleteFociBelow ~= 0
    bw_foci632 = DeleteObjectBelow(bw_foci632,foci632.DeleteFociBelow,0);
end
% whether need to only one focus
if foci632.OnlyOneFocus == 1 && (~strcmp(mask.BW,'no_mask'))
    bw_foci632 = OnlyOneFocus(mask.BW,bw_foci632,img_foci632);
end
% get 632 foci propertites
foci632.Centroid = GetBWRegionProp(img_foci632,bw_foci632,foci632.DefineCenter);
foci632.Area = GetBWRegionProp(img_foci632,bw_foci632,'area');
foci632.Perimeter = GetBWRegionProp(img_foci632,bw_foci632,'perimeter');
foci632.Intensity = GetBWRegionProp(img_foci632,bw_foci632,'intensity');
% get bw foci
foci632.BW = bw_foci632;
% return the foci belong to whick nuclei
foci632.NucleiId = BelongToNucleiId(mask.BW,foci632.Centroid);