function varargout = Gui_focilab(varargin)
% GUI_FOCILAB M-file for Gui_focilab.fig
%      GUI_FOCILAB, by itself, creates a new GUI_FOCILAB or raises the existing
%      singleton*.
%
%      H = GUI_FOCILAB returns the handle to a new GUI_FOCILAB or the handle to
%      the existing singleton*.
%
%      GUI_FOCILAB('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI_FOCILAB.M with the given input arguments.
%
%      GUI_FOCILAB('Property','Value',...) creates a new GUI_FOCILAB or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Gui_focilab_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Gui_focilab_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Gui_focilab

% Last Modified by GUIDE v2.5 10-May-2010 17:16:51

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Gui_focilab_OpeningFcn, ...
                   'gui_OutputFcn',  @Gui_focilab_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Gui_focilab is made visible.
function Gui_focilab_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Gui_focilab (see VARARGIN)

% Choose default command line output for Gui_focilab
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Gui_focilab wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Gui_focilab_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in btn_run.
function btn_run_Callback(hObject, eventdata, handles)
% hObject    handle to btn_run (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in btn_close.
function btn_close_Callback(hObject, eventdata, handles)
% hObject    handle to btn_close (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in chk_wave632535.
function chk_wave632535_Callback(hObject, eventdata, handles)
% hObject    handle to chk_wave632535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_wave632535



function edt_dis632535_Callback(hObject, eventdata, handles)
% hObject    handle to edt_dis632535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_dis632535 as text
%        str2double(get(hObject,'String')) returns contents of edt_dis632535 as a double


% --- Executes during object creation, after setting all properties.
function edt_dis632535_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_dis632535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in chk_wave632470.
function chk_wave632470_Callback(hObject, eventdata, handles)
% hObject    handle to chk_wave632470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_wave632470



function edt_dis632470_Callback(hObject, eventdata, handles)
% hObject    handle to edt_dis632470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_dis632470 as text
%        str2double(get(hObject,'String')) returns contents of edt_dis632470 as a double


% --- Executes during object creation, after setting all properties.
function edt_dis632470_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_dis632470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in chk_wave535470.
function chk_wave535470_Callback(hObject, eventdata, handles)
% hObject    handle to chk_wave535470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_wave535470



function edt_dis535470_Callback(hObject, eventdata, handles)
% hObject    handle to edt_dis535470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_dis535470 as text
%        str2double(get(hObject,'String')) returns contents of edt_dis535470 as a double


% --- Executes during object creation, after setting all properties.
function edt_dis535470_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_dis535470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edt_img470_Callback(hObject, eventdata, handles)
% hObject    handle to edt_img470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_img470 as text
%        str2double(get(hObject,'String')) returns contents of edt_img470 as a double


% --- Executes during object creation, after setting all properties.
function edt_img470_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_img470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btn_open470.
function btn_open470_Callback(hObject, eventdata, handles)
% hObject    handle to btn_open470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in pop_method470.
function pop_method470_Callback(hObject, eventdata, handles)
% hObject    handle to pop_method470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns pop_method470 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pop_method470


% --- Executes during object creation, after setting all properties.
function pop_method470_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pop_method470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edt_times470_Callback(hObject, eventdata, handles)
% hObject    handle to edt_times470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_times470 as text
%        str2double(get(hObject,'String')) returns contents of edt_times470 as a double


% --- Executes during object creation, after setting all properties.
function edt_times470_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_times470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btn_showgrad470.
function btn_showgrad470_Callback(hObject, eventdata, handles)
% hObject    handle to btn_showgrad470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in chk_cutoff470.
function chk_cutoff470_Callback(hObject, eventdata, handles)
% hObject    handle to chk_cutoff470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_cutoff470



function edt_cutoff470_Callback(hObject, eventdata, handles)
% hObject    handle to edt_cutoff470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_cutoff470 as text
%        str2double(get(hObject,'String')) returns contents of edt_cutoff470 as a double


% --- Executes during object creation, after setting all properties.
function edt_cutoff470_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_cutoff470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edt_img535_Callback(hObject, eventdata, handles)
% hObject    handle to edt_img535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_img535 as text
%        str2double(get(hObject,'String')) returns contents of edt_img535 as a double


% --- Executes during object creation, after setting all properties.
function edt_img535_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_img535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btn_open535.
function btn_open535_Callback(hObject, eventdata, handles)
% hObject    handle to btn_open535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in pop_method535.
function pop_method535_Callback(hObject, eventdata, handles)
% hObject    handle to pop_method535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns pop_method535 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pop_method535


% --- Executes during object creation, after setting all properties.
function pop_method535_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pop_method535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edt_times535_Callback(hObject, eventdata, handles)
% hObject    handle to edt_times535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_times535 as text
%        str2double(get(hObject,'String')) returns contents of edt_times535 as a double


% --- Executes during object creation, after setting all properties.
function edt_times535_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_times535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btn_showgrad535.
function btn_showgrad535_Callback(hObject, eventdata, handles)
% hObject    handle to btn_showgrad535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in chk_cutoff535.
function chk_cutoff535_Callback(hObject, eventdata, handles)
% hObject    handle to chk_cutoff535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_cutoff535



function edt_cutoff535_Callback(hObject, eventdata, handles)
% hObject    handle to edt_cutoff535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_cutoff535 as text
%        str2double(get(hObject,'String')) returns contents of edt_cutoff535 as a double


% --- Executes during object creation, after setting all properties.
function edt_cutoff535_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_cutoff535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txt_img632_Callback(hObject, eventdata, handles)
% hObject    handle to txt_img632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txt_img632 as text
%        str2double(get(hObject,'String')) returns contents of txt_img632 as a double


% --- Executes during object creation, after setting all properties.
function txt_img632_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txt_img632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btn_open632.
function btn_open632_Callback(hObject, eventdata, handles)
% hObject    handle to btn_open632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in pop_method632.
function pop_method632_Callback(hObject, eventdata, handles)
% hObject    handle to pop_method632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns pop_method632 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pop_method632


% --- Executes during object creation, after setting all properties.
function pop_method632_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pop_method632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edt_times632_Callback(hObject, eventdata, handles)
% hObject    handle to edt_times632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_times632 as text
%        str2double(get(hObject,'String')) returns contents of edt_times632 as a double


% --- Executes during object creation, after setting all properties.
function edt_times632_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_times632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btn_showgrad632.
function btn_showgrad632_Callback(hObject, eventdata, handles)
% hObject    handle to btn_showgrad632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in chk_cutoff632.
function chk_cutoff632_Callback(hObject, eventdata, handles)
% hObject    handle to chk_cutoff632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_cutoff632



function edt_cutoff632_Callback(hObject, eventdata, handles)
% hObject    handle to edt_cutoff632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_cutoff632 as text
%        str2double(get(hObject,'String')) returns contents of edt_cutoff632 as a double


% --- Executes during object creation, after setting all properties.
function edt_cutoff632_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_cutoff632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btn_show632.
function btn_show632_Callback(hObject, eventdata, handles)
% hObject    handle to btn_show632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2


% --- Executes on button press in chk_removerec632.
function chk_removerec632_Callback(hObject, eventdata, handles)
% hObject    handle to chk_removerec632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_removerec632



function edt_removefoci632_Callback(hObject, eventdata, handles)
% hObject    handle to edt_removefoci632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_removefoci632 as text
%        str2double(get(hObject,'String')) returns contents of edt_removefoci632 as a double


% --- Executes during object creation, after setting all properties.
function edt_removefoci632_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_removefoci632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in chk_onlyonefocus632.
function chk_onlyonefocus632_Callback(hObject, eventdata, handles)
% hObject    handle to chk_onlyonefocus632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_onlyonefocus632


% --- Executes on button press in chk_comint632.
function chk_comint632_Callback(hObject, eventdata, handles)
% hObject    handle to chk_comint632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_comint632


% --- Executes on selection change in pop_comint632.
function pop_comint632_Callback(hObject, eventdata, handles)
% hObject    handle to pop_comint632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns pop_comint632 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pop_comint632


% --- Executes during object creation, after setting all properties.
function pop_comint632_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pop_comint632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btn_crop632.
function btn_crop632_Callback(hObject, eventdata, handles)
% hObject    handle to btn_crop632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in btn_showcrop632.
function btn_showcrop632_Callback(hObject, eventdata, handles)
% hObject    handle to btn_showcrop632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in rad_objectcenter632.
function rad_objectcenter632_Callback(hObject, eventdata, handles)
% hObject    handle to rad_objectcenter632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rad_objectcenter632


% --- Executes on button press in rad_weightedcenter632.
function rad_weightedcenter632_Callback(hObject, eventdata, handles)
% hObject    handle to rad_weightedcenter632 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rad_weightedcenter632


% --- Executes on button press in chk_removefoci535.
function chk_removefoci535_Callback(hObject, eventdata, handles)
% hObject    handle to chk_removefoci535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_removefoci535



function edt_removefoci535_Callback(hObject, eventdata, handles)
% hObject    handle to edt_removefoci535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_removefoci535 as text
%        str2double(get(hObject,'String')) returns contents of edt_removefoci535 as a double


% --- Executes during object creation, after setting all properties.
function edt_removefoci535_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_removefoci535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in chk_onlyonefocus535.
function chk_onlyonefocus535_Callback(hObject, eventdata, handles)
% hObject    handle to chk_onlyonefocus535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_onlyonefocus535


% --- Executes on button press in chk_comint535.
function chk_comint535_Callback(hObject, eventdata, handles)
% hObject    handle to chk_comint535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_comint535


% --- Executes on selection change in pop_comint535.
function pop_comint535_Callback(hObject, eventdata, handles)
% hObject    handle to pop_comint535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns pop_comint535 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pop_comint535


% --- Executes during object creation, after setting all properties.
function pop_comint535_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pop_comint535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in chk_removefoci470.
function chk_removefoci470_Callback(hObject, eventdata, handles)
% hObject    handle to chk_removefoci470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_removefoci470



function edt_removefoci470_Callback(hObject, eventdata, handles)
% hObject    handle to edt_removefoci470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_removefoci470 as text
%        str2double(get(hObject,'String')) returns contents of edt_removefoci470 as a double


% --- Executes during object creation, after setting all properties.
function edt_removefoci470_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_removefoci470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in chk_onlyonefocus470.
function chk_onlyonefocus470_Callback(hObject, eventdata, handles)
% hObject    handle to chk_onlyonefocus470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_onlyonefocus470


% --- Executes on button press in chk_comint470.
function chk_comint470_Callback(hObject, eventdata, handles)
% hObject    handle to chk_comint470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_comint470


% --- Executes on selection change in pop_comint470.
function pop_comint470_Callback(hObject, eventdata, handles)
% hObject    handle to pop_comint470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns pop_comint470 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pop_comint470


% --- Executes during object creation, after setting all properties.
function pop_comint470_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pop_comint470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btn_show535.
function btn_show535_Callback(hObject, eventdata, handles)
% hObject    handle to btn_show535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in btn_crop535.
function btn_crop535_Callback(hObject, eventdata, handles)
% hObject    handle to btn_crop535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in btn_show470.
function btn_show470_Callback(hObject, eventdata, handles)
% hObject    handle to btn_show470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in btn_openmask.
function btn_openmask_Callback(hObject, eventdata, handles)
% hObject    handle to btn_openmask (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in btn_showmask.
function btn_showmask_Callback(hObject, eventdata, handles)
% hObject    handle to btn_showmask (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in pop_methodmask.
function pop_methodmask_Callback(hObject, eventdata, handles)
% hObject    handle to pop_methodmask (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns pop_methodmask contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pop_methodmask


% --- Executes during object creation, after setting all properties.
function pop_methodmask_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pop_methodmask (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btn_showbw.
function btn_showbw_Callback(hObject, eventdata, handles)
% hObject    handle to btn_showbw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in chk_removeobject.
function chk_removeobject_Callback(hObject, eventdata, handles)
% hObject    handle to chk_removeobject (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_removeobject


% --- Executes on button press in btn_showcrop535.
function btn_showcrop535_Callback(hObject, eventdata, handles)
% hObject    handle to btn_showcrop535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in rad_objectcenter535.
function rad_objectcenter535_Callback(hObject, eventdata, handles)
% hObject    handle to rad_objectcenter535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rad_objectcenter535


% --- Executes on button press in rad_weightedcenter535.
function rad_weightedcenter535_Callback(hObject, eventdata, handles)
% hObject    handle to rad_weightedcenter535 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rad_weightedcenter535


% --- Executes on button press in btn_crop470.
function btn_crop470_Callback(hObject, eventdata, handles)
% hObject    handle to btn_crop470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in btn_showcrop470.
function btn_showcrop470_Callback(hObject, eventdata, handles)
% hObject    handle to btn_showcrop470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in rad_objectcenter470.
function rad_objectcenter470_Callback(hObject, eventdata, handles)
% hObject    handle to rad_objectcenter470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rad_objectcenter470


% --- Executes on button press in rad_weightedcenter470.
function rad_weightedcenter470_Callback(hObject, eventdata, handles)
% hObject    handle to rad_weightedcenter470 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rad_weightedcenter470



function edt_arealow_Callback(hObject, eventdata, handles)
% hObject    handle to edt_arealow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_arealow as text
%        str2double(get(hObject,'String')) returns contents of edt_arealow as a double


% --- Executes during object creation, after setting all properties.
function edt_arealow_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_arealow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edt_areagreat_Callback(hObject, eventdata, handles)
% hObject    handle to edt_areagreat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_areagreat as text
%        str2double(get(hObject,'String')) returns contents of edt_areagreat as a double


% --- Executes during object creation, after setting all properties.
function edt_areagreat_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_areagreat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in chk_marginalobject.
function chk_marginalobject_Callback(hObject, eventdata, handles)
% hObject    handle to chk_marginalobject (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chk_marginalobject


