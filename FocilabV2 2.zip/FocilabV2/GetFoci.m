function [bw,gradx,grady] = GetFoci(img,bw_where,times,minimumcutoff)
% this function is used to return the real foci bw image

if strcmp(bw_where,'no_mask')
    gmatrix = TotalImgGrad(img);
    [gradx,grady] = GetDist(gmatrix);    
else
    [gmatrix, gradx, grady] = GetGradInfo(img,bw_where);
end
grad_cutoff = GetCutoffValue(gradx,grady,times);
[gmatrixarray,bwgmatrix] = GetBWGmatrix(gmatrix,grad_cutoff,minimumcutoff);
[bwgmatrix,modified_foci] = StretchSpots(img,bwgmatrix);
bw = bwgmatrix;


