function [x,y]=GetDist(gmatrix)

% clc
% close all
% clear
% % show the original imge
% 
% imgfoci = imread('4w470.tif');
% figure,imshow(imgfoci)
% title('Original image foci marked');
% gmatrix = GetGradsMatrix(imgfoci);
[M,N1] = size(gmatrix);
minnum = min(min(gmatrix));
maxnum = max(max(gmatrix));
N = abs(minnum)+1;
x1 = minnum : 1 : -1;
x2=  1 : 1 : maxnum;
s1 = size(x1);
s2 = size(x2);
x = [x1,x2];
y1 =zeros(1, s1(2));
y2 = zeros(1,s2(2));
for i = 1: M

        for j = 1 : N1
           
            if gmatrix(i,j) > 0
                y2(gmatrix(i,j))= y2(gmatrix(i,j))+1;
            else
                if gmatrix(i,j)< 0
                     y1(gmatrix(i,j)+N) = y1(gmatrix(i,j)+N)+1;
                end
            end
        end
   
%  y = [y1,y2];

end
 y = [y1,y2];