function array = BelongToNucleiId(bw_mask,centroid)
% this function will compute every foci in which nuclear-like object.
% the output format is 
% fociid nucleiid
% 1       3
% 2       5
% ...    ...
if strcmp(bw_mask,'no_mask')
    array = zeros(size(centroid,1),2);
    return;
end
bound = bwboundaries(bw_mask);
array = zeros(size(centroid,1),2);
for i = 1:size(centroid,1)
    temp = GetNucleiId(bound,centroid(i,2:3));
    array(i,1) = i;
    array(i,2) = temp;
end

function id = GetNucleiId(bound,cen)
id = 0;
for i = 1:length(bound)
    in = inpolygon(cen(2),cen(1),bound{i,1}(:,1),bound{i,1}(:,2));
    if in
        id = i;
        break
    end
end