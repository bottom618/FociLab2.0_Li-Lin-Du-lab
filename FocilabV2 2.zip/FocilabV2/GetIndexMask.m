function [nobj,cellarray, neobj ] = GetIndexMask (BW)
% You can get the coordinate of the object in BW object.
% It returns the cell array.
% nr points to the number of all object
% cellarray store the cooridinate of every pixel in all object.
% rnobj that is data array, stores the number of pixels in every object.

[g,nobj] = bwlabel(BW);
for i = 1:nobj    
    [cellarray{i,1},cellarray{i,2}] = find(g == i);
    [neobj(i),cnobj(i)] = size(cellarray{i,1});
end