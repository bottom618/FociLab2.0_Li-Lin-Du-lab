function BW = GetBimask( I, n )
% You can get the  binary image of an original image by different methods
% n = 0  Otsu
% n = 1 .......

switch n 
    case 0,
        trhd = graythresh(I) ;
        BW = im2bw(I,trhd);
        fprintf('You have chosed Otsu segmentation method.\n');
        
    case 1,
        fprintf('You have choosed method 1.\n');
        
    case 2,
        fprintf('You have choosed method 2.\n');
        
    otherwise
        fprintf('You must choose the fittable method.\n');
        
end