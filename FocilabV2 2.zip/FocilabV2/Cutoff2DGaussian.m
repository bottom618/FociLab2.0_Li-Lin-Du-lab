function cutoff = Cutoff2DGaussian(sub,cx,cy,sx,sy)
% get the cutoff of 2D gaussian

cx = round(cx);
cy = round(cy);
sx = round(sx);
sy = round(sy);
if cx-sx<1 row1 = 1; else row1 = cx-sx; end
if cx+sx>size(sub,1) row2 = size(sub,1); else row2 = cx+sx; end
if cy-sy<1 col1 = 1; else col1 = cy-sy; end
if cy+sy>size(sub,2) col2 = size(sub,2); else col2 = cy+sy; end
temp = sub(row1:row2,col1:col2);
cutoff = mean(temp(:));

