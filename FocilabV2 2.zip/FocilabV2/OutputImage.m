function mark = OutputImage(mask,foci632,foci535,foci470)
% output image information

if mask.WhetherExist == 1
    boundbox = mask.BoundingBox;
    maskimg = imread(mask.FileName);
    h_mask =figure('Name','where to find foci','NumberTitle','off');
    h_mask;imagesc(maskimg);
    colormap(gray);
    title('Where to find foci');
    hold on;
    for i = 1:size(boundbox,1);
        rectangle('Position',boundbox(i,2:end),'EdgeColor','y');
        text(boundbox(i,2)-5,boundbox(i,3)-5,num2str(i),'Color','y');
    end
    hold off
    maskname = mask.FileName;
    maskname = strcat(maskname(1:end-4),'_where_to_find_foci.jpg');
    saveas(h_mask,maskname,'jpg');
    close(h_mask);
end
clear boundbox;
if foci632.WhetherExist == 1
    boundbox = foci632.Centroid;
    img = imread(foci632.FileName);
    h_foci632 = figure('Name','wave 632 channel','NumberTitle','off');
    h_foci632; imagesc(img);
    colormap(gray);
    title('wave 632 channel');
    hold on;
    for i = 1:size(boundbox,1);
        plot(boundbox(i,2),boundbox(i,3),'Marker','o','MarkerEdgeColor',[239/255 105/255 199/255],'MarkerFaceColor','none');
        text(boundbox(i,2)-8,boundbox(i,3)-8,num2str(i),'Color',[239/255 105/255 199/255]);
    end
    hold off
    name632 = foci632.FileName;
    name632 = strcat(name632(1:end-4),'_foci632.jpg');
    saveas(h_foci632,name632,'jpg');
    close(h_foci632);
end
clear boundbox;
if foci535.WhetherExist == 1
    boundbox = foci535.Centroid;
    img = imread(foci535.FileName);
    h_foci535 = figure('Name','wave 535 channel','NumberTitle','off');
    h_foci535;imagesc(img);
    colormap(gray);
    title('wave 535 channel');
    hold on;
    for i = 1:size(boundbox,1);
        plot(boundbox(i,2),boundbox(i,3),'Marker','o','MarkerFaceColor','none','MarkerEdgeColor','g');
        text(boundbox(i,2)-8,boundbox(i,3)-8,num2str(i),'Color','g');
    end
    hold off
    name535 = foci535.FileName;
    name535 = strcat(name535(1:end-4),'_foci535.jpg');
    saveas(h_foci535,name535,'jpg');
    close(h_foci535);
end
clear boundbox;
if foci470.WhetherExist == 1
    boundbox = foci470.Centroid;
    img = imread(foci470.FileName);
    h_foci470 = figure('Name','wave 470 channel','NumberTitle','off');
    h_foci470;imagesc(img);
    colormap(gray);
    title('wave 470 channel');
    hold on;
    for i = 1:size(boundbox,1);
        plot(boundbox(i,2),boundbox(i,3),'Marker','o','MarkerEdgeColor',[82/255 137/255 228/255],'MarkerFaceColor','none');
        text(boundbox(i,2)-8,boundbox(i,3)-8,num2str(i),'Color',[82/255 137/255 228/255]);
    end
    hold off
    
    name470 = foci470.FileName;
    name470 = strcat(name470(1:end-4),'_foci470.jpg');
    saveas(h_foci470,name470,'jpg');
    close(h_foci470);
end

clear spot*;
clear lin*;
if foci632.WhetherExist == 1 && foci535.WhetherExist == 1

    OutputOverlapFoci(foci632,'Overlap foci between 632 channel and 535 channel','C632:','C535:',1);
    
    [overlapnum,linx632535,liny632535,correlation,spot632,spot535] = OverlapInfo(mask,foci632,foci535,1);
    if overlapnum>3
        h = figure('Name','intensity correlation for overlap foci in wave 632 and wave 535','NumberTitle','off');
        h;scatter(spot632,spot535,'Marker','o','MarkerFaceColor','blue','MarkerEdgeColor','w');
        box on
        title(['correlation is ' num2str(correlation)]);
        xlabel('wave 632');
        ylabel('wave 535');
        legend('wave 632 vs wave 535','Location','NorthWest');
        hold on
        plot(linx632535,liny632535)
        hold off
        name = foci632.FileName;
        tmp = strcat(name(1:end-4),'_overlap_for_632_535.jpg');
        saveas(h,tmp,'jpg');
        close(h);
    end
end
clear spot*;
if foci632.WhetherExist == 1 && foci470.WhetherExist == 1
    
    OutputOverlapFoci(foci470,'Overlap foci between 632 channel and 470 channel','C632:','C470:',1);
    
    [overlapnum,linx632470,liny632470,correlation,spot632,spot470] = OverlapInfo(mask,foci632,foci470,2);
     if overlapnum>3
        h = figure('Name','intensity correlation for overlap foci in wave 632 and wave 470','NumberTitle','off');
        
        h;scatter(spot632,spot470,'Marker','o','MarkerFaceColor','blue','MarkerEdgeColor','w');
        box on
        title(['correlation is ' num2str(correlation)]);
        xlabel('wave 632');
        ylabel('wave 470');
        legend('wave 632 vs wave 470','Location','NorthWest')
        hold on
        plot(linx632470,liny632470)
        hold off
        name = foci632.FileName;
        tmp = strcat(name(1:end-4),'_overlap_for_632_470.jpg');
        saveas(h,tmp,'jpg');
        close(h);
    end  
end
clear spot*;
if foci535.WhetherExist == 1 && foci470.WhetherExist == 1
    
    OutputOverlapFoci(foci535,'Overlap foci between 535 channel and 470 channel','C535:','C470:',2);
    
    [overlapnum,linx535470,liny535470,correlation,spot535,spot470] = OverlapInfo(mask,foci535,foci470,2);
     if overlapnum>3
        h = figure('Name','intensity correlation for overlap foci in wave 535 and wave 470','NumberTitle','off');
        
        h;scatter(spot535,spot470,'Marker','o','MarkerFaceColor','b','MarkerEdgeColor','w');
        title(['correlation is ' num2str(correlation)]);
        xlabel('wave 535');
        ylabel('wave 470');
        legend('wave 535 vs wave 470','Location','NorthWest');
        box on
        hold on
        plot(linx535470,liny535470)
        hold off
        name = foci535.FileName;
        tmp = strcat(name(1:end-4),'_overlap_for_535_470.jpg');
        saveas(h,tmp,'jpg');
        close(h);
    end      
end

mark = 1;


function OutputOverlapFoci(foci632,name,ch1,ch2,id)
     if id == 1
        overlap = foci632.OverlapWithFoci1;
     elseif id == 2
         overlap = foci632.OverlapWithFoci2;
     end
    cen = foci632.Centroid;
    ho = figure('Name',name,'NumberTitle','off');
    ho;imagesc(imread(foci632.FileName));
    colormap(gray);
    hold on
    for i = 1:size(cen,1)
        if overlap(i,2) ~=0
            str = strcat(ch1,num2str(overlap(i,1)),'--',ch2,num2str(overlap(i,2)));
            plot(cen(i,2),cen(i,3),'Marker','d','MarkerFaceColor','none','MarkerEdgeColor','y');
            text(cen(i,2)-8,cen(i,3)-8,str,'Color','y','FontSize',6);
        end
    end
    hold on
    file = foci632.FileName;
    tmp = regexp(file,'\');
    file = strcat(file(1:tmp(end)),name,'jpg');
    saveas(ho,file,'jpg');
    
    close(ho);